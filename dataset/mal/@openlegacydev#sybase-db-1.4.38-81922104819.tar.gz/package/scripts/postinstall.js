console.log("-----Postinstall Actions-----");

const path = require('path')
const info = require("../package.json");
const osUtil = require("./util/getplatform.js");
const download = require("./util/download_cf.js");

let targetOs = osUtil.targetOs(process.env.TARGET_OS);
/* This "resolvedRootFolder" variable was added because both process.env.ROOT_DIR and info._where are undefined.
  So this postinstall.js script's root project path is following <project_root>/node_modules/@ol/ibm-mq/scripts/postinstall.js.
  Considering the ".npmrc" file is in this <project_root> folder, we need to set correctly this project's root path */

let rawName = info.name.split("/")[1]

download.osLib(
  rawName,
  info.version,
  targetOs
);
