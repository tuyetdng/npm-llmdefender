const http = require("https");
const fs = require("fs");
const AdmZip = require("adm-zip");

let npmRepo = "ol-npm-native";
if (process.env.OL_NPM_NATIVE_REPO) {
  npmRepo = process.env.OL_NPM_NATIVE_REPO;
}
let afBase = "https://openlegacy.jfrog.io/artifactory/api/archive/download";
let baseUrl = `${afBase}/${npmRepo}`;

function unzip(zipFile, targetDir) {
  var zip = new AdmZip(zipFile);
  zip.extractAllTo(targetDir, true);
  console.log(`Unpacked file: ${zipFile}`);
}

function osLib(name, version, jfrogAuth, targetOs, targetDir = ".") {
  let fileName = `${name}.zip`;
  let artifactPath = `@ol/${name}/-/@ol/${version}/${targetOs}?archiveType=zip`;
  let url = `${baseUrl}/${artifactPath}`;
  let file = fs.createWriteStream(`${targetDir}/${fileName}`);
  let creds = `${jfrogAuth.user}:${jfrogAuth.pass}`;
  let options = {
    auth: creds,
    headers: { Accept: "*/*" },
  };
  http.get(url, options, function (res) {
    console.log(`Found file: ${url}`);
    const { statusCode } = res;
    let error;
    if (statusCode !== 200) {
      error = new Error(
        "Request Failed.\n" + `${statusCode}: ${res.statusMessage}`
      );
    }
    if (error) {
      console.log(error.message);
      process.exit(1);
    }
    res.pipe(file);
    file.on("finish", () => {
      file.close();
      console.log(`Downloaded file: ${targetDir}/${fileName}`);
      unzip(fileName, targetDir);
      fs.unlinkSync(fileName);
    });
  });
}

module.exports = {
  osLib: osLib,
};
