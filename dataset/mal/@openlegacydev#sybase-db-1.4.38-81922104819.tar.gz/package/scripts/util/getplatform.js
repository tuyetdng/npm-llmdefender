// covers simplest use-cases

let targetOs = function getPlatform(platformArg) {
  let platform;
  if (platformArg) {
    platform = platformArg;
  }
  else {
    platform = process.platform;
    switch (platform) {
      case "win32":
        platform = "windows"
        break;
      case "darwin":
        platform = "macos"
        break;
      default:
        platform = "linux";
    }
  }
  return platform;
}

module.exports = {
  targetOs: targetOs
};
