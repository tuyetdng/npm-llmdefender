// os agnostic
const fs = require("fs");
const homedir = require("os").homedir();

function getContents(filePath) {
  try {
    if (fs.existsSync(filePath)) {
      const data = fs.readFileSync(filePath, "utf8");
      return data;
    }
  } catch (err) {
    console.error(err);
  }
}
function getValue(data, key) {
  var regex = new RegExp(".*" + "openlegacy.jfrog.io" + ".*" + key + "=(.*)");
  var match = regex.exec(data);
  if (match) return match[1];
  else return null;
}
function base64decode(base64) {
  let value = Buffer.from(base64, "base64")
    .toString("ascii")
    .replace(/(\r\n|\n|\r)/g, "");
  return value;
}

function getNpmAuth(rootDir) {
  let rootNpmRc = `${rootDir}/.npmrc`;
  let homeNpmRc = `${homedir}/.npmrc`;
  let npmRc = ``;
  if (fs.existsSync(rootNpmRc)) {
    npmRc = rootNpmRc;
  } else if (fs.existsSync(homeNpmRc)) {
    npmRc = homeNpmRc;
  } else {
    console.error(`Cannot find NPM config, the following paths don't exist: '${homeNpmRc}', '${rootNpmRc}'`);
    return;
  }
  console.log(`Found NPM config: ${npmRc}`);
  let fileContents = getContents(npmRc);
  let pass = base64decode(getValue(fileContents, "_password"));
  let user = getValue(fileContents, "username");
  let npmAuth = {
    "user": user,
    "pass": pass
  }
  return npmAuth;
};

module.exports = {
  getNpmAuth: getNpmAuth
};
