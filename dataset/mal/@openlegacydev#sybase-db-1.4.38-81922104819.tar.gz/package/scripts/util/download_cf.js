const http = require("https");
const fs = require("fs");
const AdmZip = require("adm-zip");

let baseUrl = "https://ol-native.dev.ol-hub.com";

function unzip(zipFile, targetDir) {
  var zip = new AdmZip(zipFile);
  zip.extractAllTo(targetDir, true);
  console.log(`Unpacked file: ${zipFile}`);
}

function osLib(name, version, targetOs, targetDir = ".") {
  let fileName = `${name}.zip`;
  let artifactPath = `${name}/${version}/${targetOs}/${fileName}`;
  let url = `${baseUrl}/${artifactPath}`;
  let file = fs.createWriteStream(`${targetDir}/${fileName}`);

  http.get(url, function (res) {
    console.log(`Found file: ${url}`);
    const { statusCode } = res;
    let error;
    if (statusCode !== 200) {
      error = new Error(
        "Request Failed.\n" + `${statusCode}: ${res.statusMessage}`
      );
    }
    if (error) {
      console.log(error.message);
      process.exit(1);
    }
    res.pipe(file);
    file.on("finish", () => {
      file.close();
      console.log(`Downloaded file: ${targetDir}/${fileName}`);
      unzip(fileName, targetDir);
      fs.unlinkSync(fileName);
    });
  });
}

module.exports = {
  osLib: osLib,
};
