/*!
 * OpenLegacy Native Connector
 */

'use strict';

module.exports = require('./sybase-db');
