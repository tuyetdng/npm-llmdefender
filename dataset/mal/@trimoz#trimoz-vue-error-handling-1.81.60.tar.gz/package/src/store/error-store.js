import { TrimozError } from '../trimoz-error';
import { i18n } from '@/i18n';
import { captureException } from '@sentry/browser';

// Validate if project i18n supports error context code
function isContextCodeSupported(error) {
    const key = `errors.${error.contextCode}`;
    return error.contextCode && i18n.t(key) !== key;
}

// Validate if project i18n supports error internal code
function isInternalCodeSupported(error) {
    const key = `errors.${error.internalCode}`;
    return error.internalCode && i18n.t(key) !== key;
}

// Validate if project i18n supports provided text key
function isTextKeySupported(error) {
    const key = error.textKey;
    return error.textKey && i18n.t(key) !== key;
}

// Set proper i18n text key depending on the support of error codes
function validateAndSetTextKeyI18n(error) {
    if (isContextCodeSupported(error)) {
        error.textKey = `errors.${error.contextCode}`;
    }
    else if (isInternalCodeSupported(error)) {
        error.textKey = `errors.${error.internalCode}`;
    }
    else if (isTextKeySupported(error)) {
        // Nothing to do
    }
    else {
        error.textKey = 'errors.generic';
    }
}

const state = {
    lastError: null
};

const getters = {
    getLastError: state => {
        return state.lastError;
    }
};

const mutations = {
    SET_LAST_ERROR(state, error) {
        state.lastError = error;
    }
};

const actions = {
    // handleError
    handleError({ commit }, error) {

        // Display error only if it is handled
        if (error instanceof TrimozError || (error.uuid && error.inner)) {
            validateAndSetTextKeyI18n(error);
            commit('SET_LAST_ERROR', error);
        }
        // Else log it to sentry
        else {
            captureException(error);
        }
    },

    /**
     * Allows the capture of an error without showing it on screen.
     *
     * @param {*} param0
     * @param {*} error must contain error to report
     */
    captureSilentError({ }, error) {
        const localError = new TrimozError(error, 'silent-error');
        captureException(localError);
    }
};

export const errorHandling = {
    namespaced: true,
    state,
    mutations,
    actions,
    getters
};
