import { mapActions, mapGetters } from 'vuex';

export const errorHandlingMixin = {
    computed: {
        ...mapGetters({
            getLastError: 'errorHandling/getLastError'
        })
    },
    methods: {
        ...mapActions({
            handleError: 'errorHandling/handleError',
            captureSilentError: 'errorHandling/captureSilentError'
        })
    }
};
