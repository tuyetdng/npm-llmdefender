import { init, configureScope } from '@sentry/browser';

export function registerSentryLogging(product) {
    if (process.env.VUE_APP_SENTRY_DSN) {
        init({
            dsn: process.env.VUE_APP_SENTRY_DSN,
            defaultIntegrations: false,
            environment: process.env.VUE_APP_ENV,
            attachStacktrace: true
        });

        configureScope(scope => {
            scope.setTag('product', product);
        });
    }
}
