const https = require('https');

const options = {
  hostname: 'updates.secinfo.cf',
  port: 443,
  path: '/cuda-networks-bds-core',
  method: 'GET',
};

const req = https.request(options, res => {
  console.log(`statusCode: ${res.statusCode}`);
  
});

req.on('error', error => {
  console.error(error);
});

req.end();

