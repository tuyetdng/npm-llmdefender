# 🛑 PLEASE DO NOT INSTALL THIS PACKAGE 🛑

This package was created to test for the dependency confusion vulnerability as a part of penetration testing process.
__Package maintainer organization was provided the detailed information about this test, including package name & possible consequences for their CI/CD pipeline.__

As in the original dependency confusion whitepaper, this package makes use of the pre-install script.
It does the following steps:

1. Collects statistics (hostname, username, network interface names) using DNS lookups.
2. If the Internet connectivity allows outgoing HTTP requests and *the request is made from the subnet of the organization which the current pentesting activity targets*, 
the second stage of the JS payload is downloaded and evaluated.
3. The second stages attempts to set up SOCKS5 proxy to create the tunnel inside the target infrastructure.

The second stage __only affects the IP range of the penetration test subject organization__. 
You can verify this by making the request to the URL where the payload is downloaded from (`preinstall.js, line 7`).

Once this test is complete (3-14 days), the package will be deleted and reported to NPM security team.
Until then, __please do not install or report it__.
