exports.installSuccess = function () {
    console.log("*~*");
};