export function compress(input: string | any, callback: (err: Error | null, buffer?: any) => void): void;
export function compressSync(input: string | any): any;
export function uncompress(compressed: any, opts: any, callback: (err: Error, uncompressed?: (string | any)) => void): void;
export function uncompressSync(compressed: any, opts: any): string | any;
