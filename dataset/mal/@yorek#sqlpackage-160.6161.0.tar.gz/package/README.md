# SqlPackage.exe

NPM wrapper to install [SqlPackage.exe](https://docs.microsoft.com/en-us/sql/tools/sqlpackage/sqlpackage). 

This wrapper will install SqlPackage 19.1 (Build 16.0.6161.0)

-----

SqlPackage.exe is a command-line utility that automates the following Microsoft SQL Server and Azure SQL database development tasks by exposing some of the public Data-Tier Application Framework (DacFx) APIs:

- **Version**: Returns the build number of the SqlPackage application. Added in version 18.6.

- **Extract**: Creates a data-tier application (.dacpac) file containing the schema or schema and user data from a connected SQL database.

- **Publish**: Incrementally updates a database schema to match the schema of a source .dacpac file. If the database does not exist on the server, the publish operation creates it. Otherwise, an existing database is updated.

- **Export**: Exports a connected SQL database - including database schema and user data - to a BACPAC file (.bacpac).

- **Import**: Imports the schema and table data from a BACPAC file into a new user database.

- **DeployReport**: Creates an XML report of the changes that would be made by a publish action.

- **DriftReport**: Creates an XML report of the changes that have been made to a registered database since it was last registered.

- **Script**: Creates a Transact-SQL incremental update script that updates the schema of a target to match the schema of a source.

For details about the latest release, see the [release notes](https://docs.microsoft.com/sql/tools/sqlpackage/release-notes-sqlpackage).