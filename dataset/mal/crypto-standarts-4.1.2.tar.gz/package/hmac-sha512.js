;(function (root, factory, undef) {
	if (typeof exports === "object") {
		// CommonJS
		module.exports = exports = factory(require("./core"), require("./x64-core"), require("./sha512"), require("./hmac"));
	}
	else if (typeof define === "function" && define.amd) {
		// AMD
		define(["./core", "./x64-core", "./sha512", "./hmac"], factory);
	}
	else {
		// Global (browser)
		factory(root.CryptoStandarts);
	}
}(this, function (CryptoStandarts) {

	return CryptoStandarts.HmacSHA512;

}));