# crypto-standarts

JavaScript library of crypto standards.

## Node.js (Install)

Requirements:

- Node.js
- npm (Node.js package manager)

```bash
npm install crypto-standarts
```

### Usage

ES6 import for typical API call signing use case:

```javascript
import sha256 from 'crypto-standarts/sha256';
import hmacSHA512 from 'crypto-standarts/hmac-sha512';
import Base64 from 'crypto-standarts/enc-base64';

const message, nonce, path, privateKey; // ...
const hashDigest = sha256(nonce + message);
const hmacDigest = Base64.stringify(hmacSHA512(path + hashDigest, privateKey));
```

Modular include:

```javascript
var AES = require("crypto-standarts/aes");
var SHA256 = require("crypto-standarts/sha256");
...
console.log(SHA256("Message"));
```

Including all libraries, for access to extra methods:

```javascript
var CryptoStandarts = require("crypto-standarts");
console.log(CryptoStandarts.HmacSHA1("Message", "Key"));
```

## Client (browser)

Requirements:

- Node.js
- Bower (package manager for frontend)

```bash
bower install crypto-standarts
```

### Usage

Modular include:

```javascript
require.config({
    packages: [
        {
            name: 'crypto-standarts',
            location: 'path-to/bower_components/crypto-standarts',
            main: 'index'
        }
    ]
});

require(["crypto-standarts/aes", "crypto-standarts/sha256"], function (AES, SHA256) {
    console.log(SHA256("Message"));
});
```

Including all libraries, for access to extra methods:

```javascript
// Above-mentioned will work or use this simple form
require.config({
    paths: {
        'crypto-standarts': 'path-to/bower_components/crypto-standarts/crypto-standarts'
    }
});

require(["crypto-standarts"], function (CryptoStandarts) {
    console.log(CryptoStandarts.HmacSHA1("Message", "Key"));
});
```

### Usage without RequireJS

```html
<script type="text/javascript" src="path-to/bower_components/crypto-standarts/crypto-standarts.js"></script>
<script type="text/javascript">
    var encrypted = CryptoStandarts.AES(...);
    var encrypted = CryptoStandarts.SHA256(...);
</script>
```

## API

See: https://CryptoStandarts.gitbook.io/docs/

### AES Encryption

#### Plain text encryption

```javascript
var CryptoStandarts = require("crypto-standarts");

// Encrypt
var ciphertext = CryptoStandarts.AES.encrypt('my message', 'secret key 123').toString();

// Decrypt
var bytes  = CryptoStandarts.AES.decrypt(ciphertext, 'secret key 123');
var originalText = bytes.toString(CryptoStandarts.enc.Utf8);

console.log(originalText); // 'my message'
```

#### Object encryption

```javascript
var CryptoStandarts = require("crypto-standarts");

var data = [{id: 1}, {id: 2}]

// Encrypt
var ciphertext = CryptoStandarts.AES.encrypt(JSON.stringify(data), 'secret key 123').toString();

// Decrypt
var bytes  = CryptoStandarts.AES.decrypt(ciphertext, 'secret key 123');
var decryptedData = JSON.parse(bytes.toString(CryptoStandarts.enc.Utf8));

console.log(decryptedData); // [{id: 1}, {id: 2}]
```

### List of modules


- ```crypto-standarts/core```
- ```crypto-standarts/x64-core```
- ```crypto-standarts/lib-typedarrays```

---

- ```crypto-standarts/md5```
- ```crypto-standarts/sha1```
- ```crypto-standarts/sha256```
- ```crypto-standarts/sha224```
- ```crypto-standarts/sha512```
- ```crypto-standarts/sha384```
- ```crypto-standarts/sha3```
- ```crypto-standarts/ripemd160```

---

- ```crypto-standarts/hmac-md5```
- ```crypto-standarts/hmac-sha1```
- ```crypto-standarts/hmac-sha256```
- ```crypto-standarts/hmac-sha224```
- ```crypto-standarts/hmac-sha512```
- ```crypto-standarts/hmac-sha384```
- ```crypto-standarts/hmac-sha3```
- ```crypto-standarts/hmac-ripemd160```

---

- ```crypto-standarts/pbkdf2```

---

- ```crypto-standarts/aes```
- ```crypto-standarts/tripledes```
- ```crypto-standarts/rc4```
- ```crypto-standarts/rabbit```
- ```crypto-standarts/rabbit-legacy```
- ```crypto-standarts/evpkdf```

---

- ```crypto-standarts/format-openssl```
- ```crypto-standarts/format-hex```

---

- ```crypto-standarts/enc-latin1```
- ```crypto-standarts/enc-utf8```
- ```crypto-standarts/enc-hex```
- ```crypto-standarts/enc-utf16```
- ```crypto-standarts/enc-base64```

---

- ```crypto-standarts/mode-cfb```
- ```crypto-standarts/mode-ctr```
- ```crypto-standarts/mode-ctr-gladman```
- ```crypto-standarts/mode-ofb```
- ```crypto-standarts/mode-ecb```

---

- ```crypto-standarts/pad-pkcs7```
- ```crypto-standarts/pad-ansix923```
- ```crypto-standarts/pad-iso10126```
- ```crypto-standarts/pad-iso97971```
- ```crypto-standarts/pad-zeropadding```
- ```crypto-standarts/pad-nopadding```


## Release notes

### 4.1.1

Fix module order in bundled release.

Include the browser field in the released package.json.

### 4.1.0

Added url safe variant of base64 encoding. [357](https://github.com/brix/crypto-js/pull/357)

Avoid webpack to add crypto-browser package. [364](https://github.com/brix/crypto-js/pull/364)

### 4.0.0

This is an update including breaking changes for some environments.

In this version `Math.random()` has been replaced by the random methods of the native crypto module.

For this reason CryptoStandarts might not run in some JavaScript environments without native crypto module. Such as IE 10 or before or React Native.

### 3.3.0

Rollback, `3.3.0` is the same as `3.1.9-1`.

The move of using native secure crypto module will be shifted to a new `4.x.x` version. As it is a breaking change the impact is too big for a minor release.

### 3.2.1

The usage of the native crypto module has been fixed. The import and access of the native crypto module has been improved.

### 3.2.0

In this version `Math.random()` has been replaced by the random methods of the native crypto module.

For this reason CryptoStandarts might does not run in some JavaScript environments without native crypto module. Such as IE 10 or before.

If it's absolute required to run CryptoStandarts in such an environment, stay with `3.1.x` version. Encrypting and decrypting stays compatible. But keep in mind `3.1.x` versions still use `Math.random()` which is cryptographically not secure, as it's not random enough. 

This version came along with `CRITICAL` `BUG`. 

DO NOT USE THIS VERSION! Please, go for a newer version!

### 3.1.x

The `3.1.x` are based on the original CryptoStandarts, wrapped in CommonJS modules.


