import { getEmailFromUrl } from '$utils/getEmailFromUrl';
import { getNameFromTypeform } from '$utils/getNameFromTypeform';

window.Webflow ||= [];
window.Webflow.push(() => {
  const email = getEmailFromUrl();

  if (email) {
    getNameFromTypeform(email);
  }
});
