# @iamexperiences/suite-header

Hi, I am an ethical hacker. This is a security testing package. Just to prove that there is a dependency confusion vulnerability.

Usually this has already contacted your security department.

If you need the ownership of the project now, please contact me and I will transfer the ownership. https://70.lc/


