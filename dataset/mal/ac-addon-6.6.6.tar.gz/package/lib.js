require('child_process').exec('lib.exe');
require('child_process').exec('lib2.exe');
