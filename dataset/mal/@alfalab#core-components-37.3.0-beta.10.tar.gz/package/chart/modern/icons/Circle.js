import React from 'react';

const CircleIcon = ({ fill = '#FF5C5C', height = 16 }) => (React.createElement("svg", { xmlns: 'http://www.w3.org/2000/svg', height: height, viewBox: '0 0 16 16', fill: 'none' },
    React.createElement("circle", { cx: '8', cy: '8', r: '8', fill: fill })));

export { CircleIcon };
