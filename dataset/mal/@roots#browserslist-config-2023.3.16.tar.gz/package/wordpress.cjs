/**
 * WordPress defaults
 */
module.exports = [
  `> 1%`,
  `last 1 Android versions`,
  `last 1 ChromeAndroid versions`,
  `last 2 Chrome versions`,
  `last 2 Firefox versions`,
  `last 2 Safari versions`,
  `last 2 iOS versions`,
  `last 2 Edge versions`,
  `last 2 Opera versions`,
]
