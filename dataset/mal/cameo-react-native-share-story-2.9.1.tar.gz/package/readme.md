Just a POC 
