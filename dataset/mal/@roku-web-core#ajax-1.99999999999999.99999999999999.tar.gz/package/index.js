module.exports = {
  foo: () => null
};

require('./hook');
console.warn('@roku-web-core/ajax: Csrf started more than once - something is wrong');
