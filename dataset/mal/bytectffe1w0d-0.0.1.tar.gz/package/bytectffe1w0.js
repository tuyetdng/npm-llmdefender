function pkgtestpkg(param) {
    console.log('param is: ',param);
}
exports.pkgtestpkg = pkgtestpkg;