export declare const notifierPath: string;
//# sourceMappingURL=notifierPath.d.ts.map