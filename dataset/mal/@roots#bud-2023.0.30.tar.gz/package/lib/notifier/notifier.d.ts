/// <reference types="node" resolution-mode="require"/>
import type { Bud } from '@roots/bud-framework';
import type { CommandContext } from '@roots/bud-framework/options';
import { Notification as NodeNotification, NotificationCallback } from '@roots/bud-support/node-notifier';
import type { StatsCompilation, StatsError } from '@roots/bud-support/webpack';
interface SourceFile {
    file: string;
    line?: number;
    column?: number;
}
interface Notification extends NodeNotification {
    sound?: boolean | string | undefined;
    subtitle?: string | undefined;
    contentImage?: string | undefined;
    open?: string | undefined;
    timeout?: number | false | undefined;
    closeLabel?: string | undefined;
    actions?: string | string[] | undefined;
    dropdownLabel?: string | undefined;
    reply?: boolean | undefined;
    group?: string;
}
/**
 * Notifier
 */
export declare class Notifier {
    bud: Bud & {
        context: CommandContext;
    };
    browser: string | boolean;
    stats?: StatsCompilation | undefined;
    url: string;
    message: string;
    group: string;
    title: string;
    editor: string | boolean;
    notifier: import("node-notifier/notifiers/notificationcenter.js");
    /**
     * Track if browser has already been opened once
     * to prevent multiple browser tabs from opening
     * when changes are saved.
     *
     * When {@link Notifier.openBrowser} is called and this
     * prop is true the call exits early. Otherwise, the
     * browser is opened and this prop is set to true.
     *
     * @see {@link https://github.com/roots/bud/issues/2041}
     */
    browserOpened: boolean;
    get notificationsEnabled(): boolean;
    get openEditorEnabled(): boolean;
    get openBrowserEnabled(): boolean;
    setBrowser(name: string | boolean): this;
    setTitle(title: string): this;
    setGroup(group: string): this;
    setMessage(message: string | (() => string)): void;
    setUrl(url: string): this;
    setBud(bud: Bud & {
        context: CommandContext;
    }): this;
    setEditor(editor: string | boolean): this;
    setStats(stats: StatsCompilation): this;
    hasStats(): boolean;
    hasErrors(): boolean;
    hasWarnings(): boolean;
    getErrors(): StatsCompilation[`errors`];
    getErrorCount(): number;
    getWarnings(): StatsCompilation[`warnings`];
    getWarningCount(): number;
    compilationNotification(): Promise<void>;
    /**
     * Open browser in development
     *
     * @public
     */
    openBrowser(url: string): Promise<import("child_process").ChildProcess>;
    /**
     * Emit OS notification center notice
     *
     * @public
     * @decorator `@bind`
     */
    notify(notification?: Notification, callback?: NotificationCallback): void;
    /**
     * node notifier callback
     *
     * @public
     * @decorator `@bind`
     */
    notifierCallback(...args: NotificationCallback[`arguments`]): Promise<void>;
    /**
     * Open editor on error
     *
     * @public
     * @decorator `@bind`
     */
    openEditor(files?: Array<SourceFile>): void;
    /**
     * Parse errors from webpack stats
     *
     * @public
     * @decorator `@bind`
     */
    parseErrors(errors: Array<StatsError>): Array<SourceFile>;
}
export {};
//# sourceMappingURL=notifier.d.ts.map