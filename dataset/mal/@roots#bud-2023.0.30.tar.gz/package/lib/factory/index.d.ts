import { factory, Options } from './factory.js';
export { factory, Options };
//# sourceMappingURL=index.d.ts.map