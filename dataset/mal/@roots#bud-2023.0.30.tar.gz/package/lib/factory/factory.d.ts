import { Bud } from '@roots/bud';
import type { CLIContext, CommandContext, Context } from '@roots/bud-framework/options';
export interface Options {
    cache: boolean;
    find: boolean;
}
/**
 * Create a {@link Bud} instance programatically
 *
 * @example
 * ```ts
 * const bud = await factory()
 * ```
 *
 * @example
 * Running in a particular mode
 *
 * ```ts
 * const bud = await factory({mode: 'development'})
 * ```
 *
 * @returns Bud instance
 */
export declare function factory(overrides?: Partial<CLIContext | Context | CommandContext>, options?: Options): Promise<Bud>;
//# sourceMappingURL=factory.d.ts.map