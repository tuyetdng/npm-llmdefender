import type { Bud } from '@roots/bud';
import { ServiceContainer } from '@roots/bud-framework/service';
/**
 * Env service
 */
export default class Env extends ServiceContainer {
    /**
     * Bootstrap event callback
     *
     * @public
     * @decorator `@bind`
     */
    bootstrap?(bud: Bud): Promise<void>;
    /**
     * Get entries from .env which include `APP_PUBLIC` in their name
     *
     * @public
     * @decorator `@bind`
     * @decorator `@once`
     */
    getPublicEnv(): Record<string, any>;
    /**
     * Transform public env
     *
     * @public
     * @decorator `@bind`
     */
    transformPublicEnv([rawKey, rawValue]: [string, string]): [
        string,
        string
    ];
    /**
     * Filter public env
     *
     * @public
     */
    filterPublicEnv([key]: [string, string]): boolean;
}
//# sourceMappingURL=env.d.ts.map