import Env from './env.js';
export default Env;
//# sourceMappingURL=index.d.ts.map