import { Project } from './project.js';
export default Project;
//# sourceMappingURL=index.d.ts.map