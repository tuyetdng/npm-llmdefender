import type { Bud } from '@roots/bud-framework';
import { Service } from '@roots/bud-framework/service';
/**
 * Project service
 */
declare class Project extends Service {
    /**
     * `build.after` hook callback
     *
     * @public
     */
    buildAfter?(bud: Bud): Promise<void>;
}
export { Project };
//# sourceMappingURL=project.d.ts.map