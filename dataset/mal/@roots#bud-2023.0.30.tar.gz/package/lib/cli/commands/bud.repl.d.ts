import BudCommand from './bud.js';
/**
 * `bud repl`
 *
 * @public
 * @decorator `@dry` - dry run
 */
export default class BudReplCommand extends BudCommand {
    static paths: string[][];
    static usage: import("@roots/bud-support/clipanion").Usage;
    withArguments: (on: {
        dry: true;
    }) => Promise<{
        dry: true;
    }>;
    color: boolean;
    indent: string;
    depth: string;
    /**
     * Execute command
     *
     * @public
     * @decorator `@bind`
     */
    execute(): Promise<void>;
}
//# sourceMappingURL=bud.repl.d.ts.map