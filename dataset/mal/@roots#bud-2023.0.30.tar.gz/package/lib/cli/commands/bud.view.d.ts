import BudCommand from '@roots/bud/cli/commands/bud';
/**
 * `bud view` command
 */
export default class BudViewCommand extends BudCommand {
    static paths: string[][];
    static usage: import("@roots/bud-support/clipanion").Usage;
    color: boolean;
    indent: string | boolean;
    subject: string;
    execute(): Promise<void>;
}
//# sourceMappingURL=bud.view.d.ts.map