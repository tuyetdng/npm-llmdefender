/// <reference types="node" resolution-mode="require"/>
import BuildCommand from './bud.build.js';
import type { CommandContext } from './bud.js';
/**
 * `bud build production` command
 */
export default class BuildProductionCommand extends BuildCommand {
    static paths: string[][];
    static usage: import("@roots/bud-support/clipanion").Usage;
    withSubcommandContext: (context: CommandContext) => Promise<{
        mode: "production";
        args: Partial<{
            basedir: string;
            browser: string | boolean;
            cache: boolean | "memory" | "filesystem";
            ci: boolean;
            clean: boolean;
            debug: boolean;
            devtool?: false | "eval" | "eval-cheap-source-map" | "eval-cheap-module-source-map" | "eval-source-map" | "cheap-source-map" | "cheap-module-source-map" | "source-map" | "inline-cheap-source-map" | "inline-cheap-module-source-map" | "inline-source-map" | "eval-nosources-cheap-source-map" | "eval-nosources-cheap-modules-source-map" | "eval-nosources-source-map" | "inline-nosources-cheap-source-map" | "inline-nosources-cheap-module-source-map" | "inline-nosources-source-map" | "nosources-cheap-source-map" | "nosources-cheap-module-source-map" | "hidden-nosources-cheap-source-map" | "hidden-nosources-cheap-module-source-map" | "hidden-nosources-source-map" | "hidden-cheap-source-map" | "hidden-cheap-module-source-map" | "hidden-source-map";
            discover: boolean;
            dry: boolean;
            output: string;
            editor: string | boolean;
            esm: boolean;
            filter: string[];
            flush: boolean;
            hash: boolean;
            hot: boolean;
            html: string | boolean;
            immutable: boolean;
            indicator: boolean;
            input: string;
            log: boolean;
            manifest: boolean;
            minimize: boolean;
            modules: string;
            notify: boolean;
            overlay: boolean;
            publicPath: string;
            port: string;
            proxy: string;
            reload: boolean;
            runtime: boolean | "single" | "multiple";
            splitChunks: boolean;
            storage: string;
            target: string[];
            use: string[];
            verbose: boolean;
        }>;
        bin?: "node" | "ts-node" | "bun";
        stdin: import("stream").Readable;
        stdout: import("stream").Writable;
        stderr: import("stream").Writable;
        colorDepth: number;
        label: string;
        basedir: string;
        bud: Record<string, any>;
        config: Record<string, import("@roots/bud-framework/options").File>;
        env: Record<string, string>;
        extensions: {
            builtIn: string[];
            discovered: string[];
        };
        manifest: Record<string, any>;
        services: string[];
        logger: import("@roots/bud-framework").Logger;
        root?: import("@roots/bud-framework").Bud;
        dependsOn?: string[];
    }>;
}
//# sourceMappingURL=bud.build.production.d.ts.map