import BudCommand from '@roots/bud/cli/commands/bud';
/**
 * `bud upgrade` command
 *
 * @public
 * @decorator `@dry`
 */
export default class BudUpgradeCommand extends BudCommand {
    static paths: string[][];
    static usage: import("@roots/bud-support/clipanion").Usage;
    withArguments: (on: {
        dry: true;
    }) => Promise<{
        dry: true;
    }>;
    version: string;
    registry: string;
    get pacman(): `yarn` | `npm`;
    get command(): "install" | "add";
    execute(): Promise<void>;
    getUpgradeableDependencies(type: `devDependencies` | `dependencies`): Array<string>;
    getAllDependenciesOfType(type: `devDependencies` | `dependencies`): Array<string>;
    hasUpgradeableDependencies(type: `devDependencies` | `dependencies`): boolean;
    getFlags(type: `devDependencies` | `dependencies`): any[];
}
//# sourceMappingURL=bud.upgrade.d.ts.map