import BudCommand from '@roots/bud/cli/commands/bud';
/**
 * `bud clean`
 *
 * @public
 * @decorator `@dry`
 */
export default class BudCleanCommand extends BudCommand {
    static paths: string[][];
    static usage: import("@roots/bud-support/clipanion").Usage;
    _cleanStorage: boolean;
    _cleanOutput: boolean;
    /**
     * Execute command
     *
     * @public
     * @decorator `@bind`
     */
    execute(): Promise<void>;
    cleanOutput(): Promise<void[]>;
    cleanStorage(): Promise<void[]>;
}
//# sourceMappingURL=bud.clean.d.ts.map