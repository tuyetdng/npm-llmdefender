import type { CommandContext } from '@roots/bud/cli/commands/bud';
import BudCommand from '@roots/bud/cli/commands/bud';
/**
 * Build command
 */
export default class BudBuildCommand extends BudCommand {
    static paths: string[][];
    static usage: import("@roots/bud-support/clipanion").Usage;
    withBud: (bud: BudCommand[`bud`]) => Promise<import("../../index.js").Bud & {
        context: CommandContext;
    }>;
    cache: boolean | "memory" | "filesystem";
    clean: boolean;
    devtool: false | "eval" | "eval-cheap-source-map" | "eval-cheap-module-source-map" | "eval-source-map" | "cheap-source-map" | "cheap-module-source-map" | "source-map" | "inline-cheap-source-map" | "inline-cheap-module-source-map" | "inline-source-map" | "eval-nosources-cheap-source-map" | "eval-nosources-cheap-modules-source-map" | "eval-nosources-source-map" | "inline-nosources-cheap-source-map" | "inline-nosources-cheap-module-source-map" | "inline-nosources-source-map" | "nosources-cheap-source-map" | "nosources-cheap-module-source-map" | "hidden-nosources-cheap-source-map" | "hidden-nosources-cheap-module-source-map" | "hidden-nosources-source-map" | "hidden-cheap-source-map" | "hidden-cheap-module-source-map" | "hidden-source-map";
    editor: string | boolean;
    esm: boolean;
    flush: boolean;
    hash: boolean;
    html: string | boolean;
    immutable: boolean;
    discover: boolean;
    manifest: boolean;
    minimize: boolean;
    input: string;
    output: string;
    publicPath: string;
    runtime: `single` | `multiple` | boolean;
    splitChunks: boolean;
    storage: string;
    ci: boolean;
    use: string[];
    withContext: (context: CommandContext) => Promise<CommandContext>;
    withArguments: (args: BudCommand[`bud`][`context`][`args`]) => Promise<{
        cache: boolean | "memory" | "filesystem";
        ci: boolean;
        clean: boolean;
        debug: boolean;
        discover: boolean;
        devtool: false | "eval" | "eval-cheap-source-map" | "eval-cheap-module-source-map" | "eval-source-map" | "cheap-source-map" | "cheap-module-source-map" | "source-map" | "inline-cheap-source-map" | "inline-cheap-module-source-map" | "inline-source-map" | "eval-nosources-cheap-source-map" | "eval-nosources-cheap-modules-source-map" | "eval-nosources-source-map" | "inline-nosources-cheap-source-map" | "inline-nosources-cheap-module-source-map" | "inline-nosources-source-map" | "nosources-cheap-source-map" | "nosources-cheap-module-source-map" | "hidden-nosources-cheap-source-map" | "hidden-nosources-cheap-module-source-map" | "hidden-nosources-source-map" | "hidden-cheap-source-map" | "hidden-cheap-module-source-map" | "hidden-source-map";
        editor: string | boolean;
        esm: boolean;
        flush: boolean;
        hash: boolean;
        html: string | boolean;
        immutable: boolean;
        input: string;
        output: string;
        manifest: boolean;
        minimize: boolean;
        mode: "development" | "production";
        publicPath: string;
        runtime: boolean | "single" | "multiple";
        splitChunks: boolean;
        storage: string;
        target: string[];
        use: string[];
        basedir?: string;
        browser?: string | boolean;
        dry?: boolean;
        filter?: string[];
        hot?: boolean;
        indicator?: boolean;
        log?: boolean;
        modules?: string;
        notify?: boolean;
        overlay?: boolean;
        port?: string;
        proxy?: string;
        reload?: boolean;
        verbose?: boolean;
    }>;
    /**
     * Execute command
     *
     * @public
     * @decorator `@bind`
     */
    execute(): Promise<void>;
}
//# sourceMappingURL=bud.build.d.ts.map