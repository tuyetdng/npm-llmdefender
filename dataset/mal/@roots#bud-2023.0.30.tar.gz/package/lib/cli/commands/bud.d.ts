/// <reference types="react" resolution-mode="require"/>
import { Bud } from '@roots/bud';
import type { CommandContext, Context } from '@roots/bud-framework/options/context';
import { BaseContext, Command, Option } from '@roots/bud-support/clipanion';
import { React, Renderer } from '@roots/bud-support/ink';
import type { Notifier } from '../../notifier/index.js';
export type { BaseContext, CommandContext, Context };
export { Option };
export interface ArgsModifier {
    <T extends CommandContext[`args`]>(from: T): (on: T) => Promise<T>;
}
export declare const ArgsModifier: ArgsModifier;
/**
 * Bud command
 */
export default class BudCommand extends Command<CommandContext> {
    bud?: (Bud & {
        context: CommandContext;
    }) | undefined;
    get bin(): string;
    context: CommandContext;
    static paths: any[][];
    static usage: import("@roots/bud-support/clipanion").Usage;
    withArguments?: (args: CommandContext[`args`]) => Promise<CommandContext[`args`]>;
    withSubcommandArguments?: (args: CommandContext[`args`]) => Promise<CommandContext[`args`]>;
    withContext?: (context: CommandContext) => Promise<CommandContext>;
    withSubcommandContext?: (context: CommandContext) => Promise<CommandContext>;
    withBud?: (bud: BudCommand[`bud`]) => Promise<BudCommand[`bud`]>;
    notifier?: Notifier;
    notify: boolean;
    cwd: string;
    debug: boolean;
    log: boolean;
    verbose: boolean;
    mode: "development" | "production";
    filter: string[];
    renderer: Renderer;
    render(children: React.ReactElement): Promise<void>;
    renderOnce(children: React.ReactElement): Promise<void>;
    text(text: string): Promise<void>;
    constructor();
    catch(value: unknown): Promise<void>;
    makeBud<T extends BudCommand>(command: T): Promise<void>;
    run(command: BudCommand): Promise<void>;
    $(bin: string, args: Array<string>, options?: {}): Promise<import("execa").ExecaReturnValue<string>>;
    healthcheck(command: BudCommand): Promise<void>;
    applyBudEnv(bud: Bud): Promise<void>;
    applyBudManifestOptions(bud: Bud): Promise<void>;
    /**
     * Apply context from argv
     *
     * @public
     */
    applyBudArguments(bud: BudCommand[`bud`]): Promise<void>;
    execute(): Promise<void>;
}
//# sourceMappingURL=bud.d.ts.map