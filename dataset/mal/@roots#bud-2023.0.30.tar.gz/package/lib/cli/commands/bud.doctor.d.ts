/// <reference types="react" resolution-mode="require"/>
import BudCommand from '@roots/bud/cli/commands/bud';
import type { Extension } from '@roots/bud-framework';
import type { CommandContext } from '@roots/bud-framework/options';
import webpack from '@roots/bud-support/webpack';
/**
 * `bud doctor` command
 *
 * @public
 * @decorator `@dry`
 */
export default class BudDoctorCommand extends BudCommand {
    static paths: string[][];
    static usage: import("@roots/bud-support/clipanion").Usage;
    withArguments: (args: CommandContext[`args`]) => Promise<{
        cache: boolean;
        dry: boolean;
        basedir?: string;
        browser?: string | boolean;
        ci?: boolean;
        clean?: boolean;
        debug?: boolean;
        devtool?: false | "eval" | "eval-cheap-source-map" | "eval-cheap-module-source-map" | "eval-source-map" | "cheap-source-map" | "cheap-module-source-map" | "source-map" | "inline-cheap-source-map" | "inline-cheap-module-source-map" | "inline-source-map" | "eval-nosources-cheap-source-map" | "eval-nosources-cheap-modules-source-map" | "eval-nosources-source-map" | "inline-nosources-cheap-source-map" | "inline-nosources-cheap-module-source-map" | "inline-nosources-source-map" | "nosources-cheap-source-map" | "nosources-cheap-module-source-map" | "hidden-nosources-cheap-source-map" | "hidden-nosources-cheap-module-source-map" | "hidden-nosources-source-map" | "hidden-cheap-source-map" | "hidden-cheap-module-source-map" | "hidden-source-map";
        discover?: boolean;
        output?: string;
        editor?: string | boolean;
        esm?: boolean;
        filter?: string[];
        flush?: boolean;
        hash?: boolean;
        hot?: boolean;
        html?: string | boolean;
        immutable?: boolean;
        indicator?: boolean;
        input?: string;
        log?: boolean;
        manifest?: boolean;
        minimize?: boolean;
        modules?: string;
        notify?: boolean;
        overlay?: boolean;
        publicPath?: string;
        port?: string;
        proxy?: string;
        reload?: boolean;
        runtime?: boolean | "single" | "multiple";
        splitChunks?: boolean;
        storage?: string;
        target?: string[];
        use?: string[];
        verbose?: boolean;
    }>;
    configuration: webpack.Configuration;
    enabledExtensions: Array<[string, Extension]>;
    disabledExtensions: Array<[string, Extension]>;
    entrypoints: Array<[string, webpack.EntryObject]>;
    /**
     * Execute command
     *
     * @public
     * @decorator `@bind`
     */
    execute(): Promise<void>;
    mapExtensions(extensions: Array<[string, Extension]>): JSX.Element[];
    mapEntrypoints(entrypoints: Array<[string, webpack.EntryObject]>): JSX.Element[];
    ls(path: string): Promise<JSX.Element[]>;
    packageCheck(signifier: string): Promise<JSX.Element>;
}
//# sourceMappingURL=bud.doctor.d.ts.map