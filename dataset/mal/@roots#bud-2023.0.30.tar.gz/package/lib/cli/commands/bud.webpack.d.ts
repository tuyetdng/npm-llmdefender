import BudCommand from '@roots/bud/cli/commands/bud';
/**
 * `bud webpack` command
 */
export default class BudWebpackCommand extends BudCommand {
    static paths: string[][];
    static usage: import("@roots/bud-support/clipanion").Usage;
    options: string[];
    /**
     * Command execute
     *
     * @public
     */
    execute(): Promise<void>;
}
//# sourceMappingURL=bud.webpack.d.ts.map