/// <reference types="react" resolution-mode="require"/>
import React from '@roots/bud-support/react';
export type Props = React.PropsWithChildren<{
    label: string;
    message?: React.ReactElement | string;
}>;
export declare const Error: ({ children, label, message }: Props) => JSX.Element;
export declare const Message: ({ children }: React.PropsWithChildren<{}>) => JSX.Element;
//# sourceMappingURL=Error.d.ts.map