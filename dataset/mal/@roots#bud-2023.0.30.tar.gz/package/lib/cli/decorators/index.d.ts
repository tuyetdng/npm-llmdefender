import { dry } from './command.dry.js';
export { dry };
//# sourceMappingURL=index.d.ts.map