export declare function dry(constructor: any): any;
//# sourceMappingURL=command.dry.d.ts.map