/**
 * Returns true if the given value is neither null nor undefined.
 */
export declare const isset: (value: unknown) => boolean;
//# sourceMappingURL=isset.d.ts.map