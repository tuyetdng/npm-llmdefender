import type { Bud } from '@roots/bud';
export declare const isInternalDevelopmentEnv: (bud: Bud) => boolean;
//# sourceMappingURL=isInternalDevelopmentEnv.d.ts.map