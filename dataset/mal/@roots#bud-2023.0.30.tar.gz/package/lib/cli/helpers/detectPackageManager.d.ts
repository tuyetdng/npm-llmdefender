import type { Bud } from '@roots/bud';
export declare const isYarn: (bud: Bud) => any;
export declare const isNpm: (bud: Bud) => any;
export declare const detectPackageManager: (bud: Bud) => `yarn` | `npm` | false;
//# sourceMappingURL=detectPackageManager.d.ts.map