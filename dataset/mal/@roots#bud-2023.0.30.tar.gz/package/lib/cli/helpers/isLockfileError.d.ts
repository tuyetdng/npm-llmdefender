import type { Bud } from '@roots/bud';
export declare const isLockConflict: (bud: Bud) => boolean;
export declare const isNoLock: (bud: Bud) => boolean;
export declare const lockError: (bud: Bud) => boolean;
//# sourceMappingURL=isLockfileError.d.ts.map