import type { Bud } from '@roots/bud';
export declare const checkPackageManagerErrors: (bud: Bud) => boolean;
//# sourceMappingURL=checkPackageManagerErrors.d.ts.map