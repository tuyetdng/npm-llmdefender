import type { Bud } from '@roots/bud';
export declare const checkDependencies: (bud: Bud) => Promise<number | false>;
//# sourceMappingURL=checkDependencies.d.ts.map