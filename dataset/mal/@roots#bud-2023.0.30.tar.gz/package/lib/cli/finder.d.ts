import type * as cli from '@roots/bud/cli/app';
import type { Context } from '@roots/bud-framework/options';
/**
 * Command finder class
 */
export declare class Commands {
    context: Partial<Context>;
    application: cli.Cli;
    /**
     * @public
     */
    static instance: Commands;
    /**
     * @internal
     */
    private constructor();
    /**
     * @public
     * @static
     */
    static get(application: cli.Cli, context: Partial<Context>): Commands;
    /**
     * @decorator `@bind`
     * @public
     */
    getCommands(): Promise<any[]>;
    /**
     * @decorator `@bind`
     * @public
     */
    getRegistrationModulePaths(): Promise<Array<any>>;
    /**
     * Get array of project dependency and devDependency signifiers
     * @decorator `@bind`
     * @public
     */
    getProjectDependencySignifiers(): Array<string>;
    /**
     * Find commands shipped with a given extension
     * @decorator `@bind`
     * @public
     */
    findExtensionCommandPaths(paths: Array<string>): Promise<string[]>;
    resolveExtensionCommandPaths(paths: Array<string>): Promise<string[]>;
    /**
     * Import and register commands with the clipanion app
     * @decorator `@bind`
     */
    registerExtensionCommandPaths(registerCallback: CallableFunction): Promise<void>;
    static importCommandsFromPaths(paths: Array<string>): Promise<any>;
}
//# sourceMappingURL=finder.d.ts.map