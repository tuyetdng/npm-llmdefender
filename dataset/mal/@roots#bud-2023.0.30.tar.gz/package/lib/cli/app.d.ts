import { Builtins, Cli, CommandClass } from '@roots/bud-support/clipanion';
declare const application: Cli<import("@roots/bud-support/clipanion").BaseContext>;
export { application, Builtins, Cli, CommandClass };
//# sourceMappingURL=app.d.ts.map