import type Api from '@roots/bud-api';
import type Build from '@roots/bud-build';
import type Cache from '@roots/bud-cache';
import type Compiler from '@roots/bud-compiler';
import type Dashboard from '@roots/bud-dashboard';
import type Extensions from '@roots/bud-extensions';
import { Bud as Framework } from '@roots/bud-framework';
import { Service, ServiceContainer } from '@roots/bud-framework';
import type Hooks from '@roots/bud-hooks';
import type Server from '@roots/bud-server';
/**
 * ## ⚡️ Bud
 *
 * {@link https://bud.js.org/ bud.js}
 */
export declare class Bud extends Framework {
    implementation: typeof Bud;
    api: Api;
    build: Build;
    cache: Cache;
    compiler: Compiler;
    dashboard: Dashboard;
    extensions: Extensions;
    hooks: Hooks;
    server: Server;
}
export { Service, ServiceContainer };
//# sourceMappingURL=bud.d.ts.map