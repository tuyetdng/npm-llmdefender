import { Bud } from '@roots/bud';
/**
 * Bud instance cache
 */
declare let instances: Record<string, Bud>;
declare const get: (key?: string) => Bud;
declare const has: (key: keyof typeof instances) => boolean;
declare const set: (path: string, bud: Bud) => Bud;
export { get, set, has, instances };
//# sourceMappingURL=instances.d.ts.map