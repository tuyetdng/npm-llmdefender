import type { Config } from '@roots/bud-support/signale';
/**
 * Instance configuration
 *
 * @internal
 */
export declare const config: Config;
export declare const level: string[];
export declare const types: {
    error: {
        badge: string;
        color: string;
        label: string;
        logLevel: string;
    };
    fatal: {
        badge: string;
        color: string;
        label: string;
        logLevel: string;
    };
    warn: {
        badge: string;
        color: string;
        label: string;
        logLevel: string;
    };
    success: {
        badge: string;
        color: string;
        label: string;
        logLevel: string;
    };
    log: {
        badge: string;
        color: string;
        label: string;
        logLevel: string;
    };
    info: {
        badge: string;
        color: string;
        label: string;
        logLevel: string;
    };
    debug: {
        badge: string;
        color: string;
        label: string;
        logLevel: string;
    };
};
//# sourceMappingURL=options.d.ts.map