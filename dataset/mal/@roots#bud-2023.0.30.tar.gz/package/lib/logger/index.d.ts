import { Instance, Options as SignaleOptions } from '@roots/bud-support/signale';
interface Options extends SignaleOptions {
    logLevel?: `log` | `info` | `warn`;
}
export declare class Logger {
    commonPath: string;
    instance: Instance;
    constructor(options?: Options);
    make(...scope: Array<string>): Logger;
    setCommonPath(path: string): Promise<this>;
    /**
     * Format logger messages
     *
     * @param messages - any
     * @public
     * @decorator `@bind`
     */
    format(...messages: Array<unknown>): unknown[];
    log(...messages: Array<unknown>): this;
    time(label: string): this;
    timeEnd(label: string): this;
    success(...messages: Array<unknown>): this;
    info(...messages: Array<unknown>): this;
    warn(...messages: Array<unknown>): this;
    error(...messages: Array<unknown>): this;
    fatal(...messages: Array<unknown>): this;
    debug(...messages: Array<unknown>): this;
    fav(...messages: Array<unknown>): this;
    pending(...messages: Array<unknown>): this;
    star(...messages: Array<unknown>): this;
    await(...messages: Array<unknown>): this;
    scope(...scopes: Array<string>): this;
}
export {};
//# sourceMappingURL=index.d.ts.map