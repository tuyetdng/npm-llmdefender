/**
 * Context: env
 */
declare const _default: ({ basedir, ...overrides }: {
    [x: string]: any;
    basedir: any;
}) => {
    [x: string]: any;
};
export default _default;
//# sourceMappingURL=env.d.ts.map