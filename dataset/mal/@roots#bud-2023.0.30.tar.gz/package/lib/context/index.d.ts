import type * as Factory from '@roots/bud/factory';
import type { CommandContext, Context } from '@roots/bud-framework/options';
declare const _default: ({ basedir, ...overrides }: Partial<CommandContext>, options?: Factory.Options) => Promise<Context>;
export default _default;
//# sourceMappingURL=index.d.ts.map