import type { Modules } from '@roots/bud-framework';
import type { Context } from '@roots/bud-framework/options';
interface Extensions {
    builtIn: Partial<Array<keyof Modules & string>>;
    discovered: Array<string>;
}
declare const _default: (manifest: Context[`manifest`], find: boolean) => Extensions;
export default _default;
//# sourceMappingURL=extensions.d.ts.map