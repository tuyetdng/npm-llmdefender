import type { File } from './config.js';
declare const _default: (config: Record<string, File>) => any;
export default _default;
//# sourceMappingURL=manifest.d.ts.map