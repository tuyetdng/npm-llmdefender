declare const _default: string[];
export default _default;
//# sourceMappingURL=services.d.ts.map