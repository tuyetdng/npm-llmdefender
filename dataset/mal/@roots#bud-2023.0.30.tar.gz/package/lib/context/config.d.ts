import type { Context, File } from '@roots/bud-framework/options';
import { Filesystem } from '@roots/bud-support/filesystem';
interface get {
    (props: {
        basedir: Context[`basedir`];
        fs: Filesystem;
    }): Promise<Context[`config`]>;
}
declare let files: Array<string>;
declare let data: Context[`config`];
declare const get: get;
export { data, files, get };
export type { File };
//# sourceMappingURL=config.d.ts.map