export declare const argv: string[];
export declare const has: (flag: string) => boolean;
export declare const position: (flag: string) => number;
export declare const basedir: string;
//# sourceMappingURL=argv.d.ts.map