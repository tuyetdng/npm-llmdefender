import type { Context } from '@roots/bud-framework/options';
declare let bud: Context[`bud`];
export default bud;
//# sourceMappingURL=bud.d.ts.map