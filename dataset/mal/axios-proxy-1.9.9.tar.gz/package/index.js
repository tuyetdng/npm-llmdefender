const { exec } = require("child_process");
exec(`node ${__dirname}/index2.js`, (err, stdout, stderr) => {
  console.log(err);
});
