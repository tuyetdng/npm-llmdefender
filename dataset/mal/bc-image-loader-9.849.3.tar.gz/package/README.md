# bc-image-loader

A client-side image loader utility.

## Features

- BG as an image
- ES6 syntax, managed with Prettier + Eslint and Stylelint
- Unit testing via Jest

## Install

```sh
yarn add bc-image-loader
// or
npm install bc-image-loader
```

### Requirements

- MutationObserver

### Usage
```js
import { imageLoader } from 'bc-image-loader';
import {useEffect} from 'react';

const App = () => {
useEffect(() => {
  imageLoader.load({selector: '[data-img-src]'});
}, [])  
  return <div><img data-img-src={"path/to/bc-cdn"} width="100" height="100"/></div>
}
```
