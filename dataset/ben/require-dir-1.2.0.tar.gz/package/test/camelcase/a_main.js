module.exports = 'a main';
