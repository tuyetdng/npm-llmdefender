export const foo: 'bar';
