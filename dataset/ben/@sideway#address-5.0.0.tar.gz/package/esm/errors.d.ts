export declare const errorCodes: Record<string, string>;
export declare function errorCode(code: string): {
    code: string;
    error: string;
};
