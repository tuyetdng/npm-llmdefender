import { SsoProfile } from "./types";
export declare const validateSsoProfile: (
  profile: Partial<SsoProfile>
) => SsoProfile;
