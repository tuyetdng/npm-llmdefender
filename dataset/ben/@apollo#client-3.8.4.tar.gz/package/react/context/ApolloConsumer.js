import { invariant } from "../../utilities/globals/index.js";
import * as React from "react";
import { getApolloContext } from "./ApolloContext.js";
export var ApolloConsumer = function (props) {
    var ApolloContext = getApolloContext();
    return (React.createElement(ApolloContext.Consumer, null, function (context) {
        invariant(context && context.client, 42);
        return props.children(context.client);
    }));
};
//# sourceMappingURL=ApolloConsumer.js.map