import "../utilities/globals/index.js";
export { ApolloProvider, ApolloConsumer, getApolloContext, resetApolloContext, } from "./context/index.js";
export * from "./hooks/index.js";
export { SuspenseCache } from "./cache/index.js";
export { DocumentType, operationName, parser } from "./parser/index.js";
export * from "./types/types.js";
//# sourceMappingURL=index.js.map