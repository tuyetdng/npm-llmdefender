import { __extends } from "tslib";
export { getSuspenseCache } from "./getSuspenseCache.js";
import { SuspenseCache as RealSuspenseCache } from "./SuspenseCache.js";
var SuspenseCache = (function (_super) {
    __extends(SuspenseCache, _super);
    function SuspenseCache() {
        var _this = _super.call(this) || this;
        throw new Error("It is no longer necessary to create a `SuspenseCache` instance and pass it into the `ApolloProvider`.\n" +
            "Please remove this code from your application. \n\n" +
            "This export will be removed with the final 3.8 release.");
        return _this;
    }
    return SuspenseCache;
}(RealSuspenseCache));
export { SuspenseCache };
//# sourceMappingURL=index.js.map