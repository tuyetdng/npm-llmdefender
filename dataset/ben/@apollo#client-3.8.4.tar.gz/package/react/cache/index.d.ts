export type { SuspenseCacheOptions } from "./SuspenseCache.js";
export { getSuspenseCache } from "./getSuspenseCache.js";
import { SuspenseCache as RealSuspenseCache } from "./SuspenseCache.js";
export declare class SuspenseCache extends RealSuspenseCache {
    constructor();
}
//# sourceMappingURL=index.d.ts.map