import type { QueryReference } from "../cache/QueryReference.js";
export declare function useReadQuery<TData>(queryRef: QueryReference<TData>): {
    data: TData;
    networkStatus: import("../../index.js").NetworkStatus;
    error: import("../../index.js").ApolloError | undefined;
};
//# sourceMappingURL=useReadQuery.d.ts.map