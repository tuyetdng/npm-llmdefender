export var version = "3.8.4";
//# sourceMappingURL=version.js.map