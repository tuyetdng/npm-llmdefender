import * as React from "react";
import { HTMLInputProps } from "../../common";
export type Ref = HTMLInputElement;
export declare const ResizableInput: React.ForwardRefExoticComponent<HTMLInputProps & React.RefAttributes<HTMLInputElement>>;
