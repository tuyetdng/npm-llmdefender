/// <reference types="react" />
import { AbstractPureComponent } from "../../common";
import { HTMLDivProps, Props } from "../../common/props";
export interface NavbarDividerProps extends Props, HTMLDivProps {
}
export declare class NavbarDivider extends AbstractPureComponent<NavbarDividerProps> {
    static displayName: string;
    render(): JSX.Element;
}
