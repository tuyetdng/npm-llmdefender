/// <reference types="react" />
import { ButtonSharedPropsAndAttributes } from "../button/buttonProps";
import { TooltipProps } from "../tooltip/tooltip";
export type DialogStepButtonProps = Partial<ButtonSharedPropsAndAttributes> & {
    /** If defined, the button will be wrapped with a tooltip with the specified content. */
    tooltipContent?: TooltipProps["content"];
};
export declare function DialogStepButton({ tooltipContent, ...props }: DialogStepButtonProps): JSX.Element;
