import { Placement } from "@popperjs/core";
import { PopoverPosition } from "./popoverSharedProps";
/**
 * Convert a position to a placement.
 *
 * @param position the position to convert
 */
export declare function positionToPlacement(position: PopoverPosition): Placement;
