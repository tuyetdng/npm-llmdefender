/** @deprecated use named keys instead of key codes */
export declare const KeyCodes: {
    BACKSPACE: number;
    TAB: number;
    ENTER: number;
    SHIFT: number;
    ESCAPE: number;
    SPACE: number;
    ARROW_LEFT: number;
    ARROW_UP: number;
    ARROW_RIGHT: number;
    ARROW_DOWN: number;
    DELETE: number;
};
