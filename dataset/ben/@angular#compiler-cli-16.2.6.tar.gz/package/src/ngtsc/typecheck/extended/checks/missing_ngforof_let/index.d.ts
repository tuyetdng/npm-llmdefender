/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ErrorCode, ExtendedTemplateDiagnosticName } from '../../../../diagnostics';
import { TemplateCheckFactory } from '../../api';
export declare const factory: TemplateCheckFactory<ErrorCode.MISSING_NGFOROF_LET, ExtendedTemplateDiagnosticName.MISSING_NGFOROF_LET>;
