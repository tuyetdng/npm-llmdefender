/**
 * Generates a new, generic end-to-end test definition in the given project.
 */
export interface Schema {
    /**
     * The name of the application being tested.
     */
    relatedAppName: string;
    /**
     * The HTML selector for the root component of the test app.
     */
    rootSelector?: string;
}
