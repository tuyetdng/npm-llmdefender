export { hasOwnProperty } from './hasOwnProperty';
