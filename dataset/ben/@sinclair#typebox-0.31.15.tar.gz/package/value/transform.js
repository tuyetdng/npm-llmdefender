"use strict";
/*--------------------------------------------------------------------------

@sinclair/typebox/value

The MIT License (MIT)

Copyright (c) 2017-2023 Haydn Paterson (sinclair) <haydn.developer@gmail.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

---------------------------------------------------------------------------*/
Object.defineProperty(exports, "__esModule", { value: true });
exports.EncodeTransform = exports.DecodeTransform = exports.HasTransform = exports.TransformEncodeError = exports.TransformDecodeError = exports.TransformEncodeCheckError = exports.TransformDecodeCheckError = exports.TransformUnknownTypeError = void 0;
const guard_1 = require("./guard");
const deref_1 = require("./deref");
const Types = require("../typebox");
// -------------------------------------------------------------------------
// Errors
// -------------------------------------------------------------------------
class TransformUnknownTypeError extends Types.TypeBoxError {
    constructor(schema) {
        super(`Unknown type`);
        this.schema = schema;
    }
}
exports.TransformUnknownTypeError = TransformUnknownTypeError;
class TransformDecodeCheckError extends Types.TypeBoxError {
    constructor(schema, value, error) {
        super(`Unable to decode due to invalid value`);
        this.schema = schema;
        this.value = value;
        this.error = error;
    }
}
exports.TransformDecodeCheckError = TransformDecodeCheckError;
class TransformEncodeCheckError extends Types.TypeBoxError {
    constructor(schema, value, error) {
        super(`Unable to encode due to invalid value`);
        this.schema = schema;
        this.value = value;
        this.error = error;
    }
}
exports.TransformEncodeCheckError = TransformEncodeCheckError;
class TransformDecodeError extends Types.TypeBoxError {
    constructor(schema, value, error) {
        super(`${error instanceof Error ? error.message : 'Unknown error'}`);
        this.schema = schema;
        this.value = value;
    }
}
exports.TransformDecodeError = TransformDecodeError;
class TransformEncodeError extends Types.TypeBoxError {
    constructor(schema, value, error) {
        super(`${error instanceof Error ? error.message : 'Unknown error'}`);
        this.schema = schema;
        this.value = value;
    }
}
exports.TransformEncodeError = TransformEncodeError;
// -------------------------------------------------------------------------
// HasTransform
// -------------------------------------------------------------------------
/** Recursively checks a schema for transform codecs */
var HasTransform;
(function (HasTransform) {
    function TArray(schema, references) {
        return Types.TypeGuard.TTransform(schema) || Visit(schema.items, references);
    }
    function TAsyncIterator(schema, references) {
        return Types.TypeGuard.TTransform(schema) || Visit(schema.items, references);
    }
    function TConstructor(schema, references) {
        return Types.TypeGuard.TTransform(schema) || Visit(schema.returns, references) || schema.parameters.some((schema) => Visit(schema, references));
    }
    function TFunction(schema, references) {
        return Types.TypeGuard.TTransform(schema) || Visit(schema.returns, references) || schema.parameters.some((schema) => Visit(schema, references));
    }
    function TIntersect(schema, references) {
        return Types.TypeGuard.TTransform(schema) || Types.TypeGuard.TTransform(schema.unevaluatedProperties) || schema.allOf.some((schema) => Visit(schema, references));
    }
    function TIterator(schema, references) {
        return Types.TypeGuard.TTransform(schema) || Visit(schema.items, references);
    }
    function TNot(schema, references) {
        return Types.TypeGuard.TTransform(schema) || Visit(schema.not, references);
    }
    function TObject(schema, references) {
        // prettier-ignore
        return (Types.TypeGuard.TTransform(schema) || Object.values(schema.properties).some((schema) => Visit(schema, references)) || Types.TypeGuard.TSchema(schema.additionalProperties) && Visit(schema.additionalProperties, references));
    }
    function TPromise(schema, references) {
        return Types.TypeGuard.TTransform(schema) || Visit(schema.item, references);
    }
    function TRecord(schema, references) {
        const pattern = Object.getOwnPropertyNames(schema.patternProperties)[0];
        const property = schema.patternProperties[pattern];
        return Types.TypeGuard.TTransform(schema) || Visit(property, references) || (Types.TypeGuard.TSchema(schema.additionalProperties) && Types.TypeGuard.TTransform(schema.additionalProperties));
    }
    function TRef(schema, references) {
        if (Types.TypeGuard.TTransform(schema))
            return true;
        return Visit((0, deref_1.Deref)(schema, references), references);
    }
    function TThis(schema, references) {
        if (Types.TypeGuard.TTransform(schema))
            return true;
        return Visit((0, deref_1.Deref)(schema, references), references);
    }
    function TTuple(schema, references) {
        return Types.TypeGuard.TTransform(schema) || (Types.TypeGuard.TSchema(schema.items) && schema.items.some((schema) => Visit(schema, references)));
    }
    function TUnion(schema, references) {
        return Types.TypeGuard.TTransform(schema) || schema.anyOf.some((schema) => Visit(schema, references));
    }
    function Visit(schema, references) {
        const references_ = (0, guard_1.IsString)(schema.$id) ? [...references, schema] : references;
        const schema_ = schema;
        if (schema.$id && visited.has(schema.$id))
            return false;
        if (schema.$id)
            visited.add(schema.$id);
        switch (schema[Types.Kind]) {
            // ------------------------------------------------------
            // Structural
            // ------------------------------------------------------
            case 'Array':
                return TArray(schema_, references_);
            case 'AsyncIterator':
                return TAsyncIterator(schema_, references_);
            case 'Constructor':
                return TConstructor(schema_, references_);
            case 'Function':
                return TFunction(schema_, references_);
            case 'Intersect':
                return TIntersect(schema_, references_);
            case 'Iterator':
                return TIterator(schema_, references_);
            case 'Not':
                return TNot(schema_, references_);
            case 'Object':
                return TObject(schema_, references_);
            case 'Promise':
                return TPromise(schema_, references_);
            case 'Record':
                return TRecord(schema_, references_);
            case 'Ref':
                return TRef(schema_, references_);
            case 'This':
                return TThis(schema_, references_);
            case 'Tuple':
                return TTuple(schema_, references_);
            case 'Union':
                return TUnion(schema_, references_);
            // ------------------------------------------------------
            // Default
            // ------------------------------------------------------
            case 'Any':
            case 'BigInt':
            case 'Boolean':
            case 'Date':
            case 'Integer':
            case 'Literal':
            case 'Never':
            case 'Null':
            case 'Number':
            case 'String':
            case 'Symbol':
            case 'TemplateLiteral':
            case 'Undefined':
            case 'Uint8Array':
            case 'Unknown':
            case 'Void':
                return Types.TypeGuard.TTransform(schema);
            default:
                if (!Types.TypeRegistry.Has(schema_[Types.Kind]))
                    throw new TransformUnknownTypeError(schema_);
                return Types.TypeGuard.TTransform(schema);
        }
    }
    const visited = new Set();
    /** Returns true if this schema contains a transform codec */
    function Has(schema, references) {
        visited.clear();
        return Visit(schema, references);
    }
    HasTransform.Has = Has;
})(HasTransform || (exports.HasTransform = HasTransform = {}));
// -------------------------------------------------------------------------
// DecodeTransform
// -------------------------------------------------------------------------
/** Decodes a value using transform decoders if available. Does not ensure correct results. */
var DecodeTransform;
(function (DecodeTransform) {
    function Default(schema, value) {
        try {
            return Types.TypeGuard.TTransform(schema) ? schema[Types.Transform].Decode(value) : value;
        }
        catch (error) {
            throw new TransformDecodeError(schema, value, error);
        }
    }
    function TArray(schema, references, value) {
        const elements1 = value.map((value) => Visit(schema.items, references, value));
        return Default(schema, elements1);
    }
    function TIntersect(schema, references, value) {
        if (!(0, guard_1.IsPlainObject)(value) || (0, guard_1.IsValueType)(value))
            return Default(schema, value);
        const keys = Types.KeyResolver.ResolveKeys(schema, { includePatterns: false });
        const properties1 = Object.entries(value).reduce((acc, [key, value]) => {
            return !keys.includes(key) ? { ...acc, [key]: value } : { ...acc, [key]: Default(Types.IndexedAccessor.Resolve(schema, [key]), value) };
        }, {});
        if (!Types.TypeGuard.TTransform(schema.unevaluatedProperties))
            return Default(schema, properties1);
        const properties2 = Object.entries(properties1).reduce((acc, [key, value]) => {
            return keys.includes(key) ? { ...acc, [key]: value } : { ...acc, [key]: Default(schema.unevaluatedProperties, value) };
        }, {});
        return Default(schema, properties2);
    }
    function TNot(schema, references, value) {
        const value1 = Visit(schema.not, references, value);
        return Default(schema, value1);
    }
    function TObject(schema, references, value) {
        if (!(0, guard_1.IsPlainObject)(value))
            return Default(schema, value);
        const properties1 = Object.entries(value).reduce((acc, [key, value]) => {
            return !(key in schema.properties) ? { ...acc, [key]: value } : { ...acc, [key]: Visit(schema.properties[key], references, value) };
        }, {});
        if (!Types.TypeGuard.TSchema(schema.additionalProperties))
            return Default(schema, properties1);
        const additionalProperties = schema.additionalProperties;
        const properties2 = Object.entries(properties1).reduce((acc, [key, value]) => {
            return key in schema.properties ? { ...acc, [key]: value } : { ...acc, [key]: Visit(additionalProperties, references, value) };
        }, {});
        return Default(schema, properties2);
    }
    function TRecord(schema, references, value) {
        if (!(0, guard_1.IsPlainObject)(value))
            return Default(schema, value);
        const pattern = Object.getOwnPropertyNames(schema.patternProperties)[0];
        const property = schema.patternProperties[pattern];
        const regex = new RegExp(pattern);
        const properties1 = Object.entries(value).reduce((acc, [key, value]) => {
            return !regex.test(key) ? { ...acc, [key]: value } : { ...acc, [key]: Visit(property, references, value) };
        }, {});
        if (!Types.TypeGuard.TSchema(schema.additionalProperties))
            return Default(schema, properties1);
        const additionalProperties = schema.additionalProperties;
        const properties2 = Object.entries(properties1).reduce((acc, [key, value]) => {
            return regex.test(key) ? { ...acc, [key]: value } : { ...acc, [key]: Visit(additionalProperties, references, value) };
        }, {});
        return Default(schema, properties2);
    }
    function TRef(schema, references, value) {
        const target = (0, deref_1.Deref)(schema, references);
        const resolved = Visit(target, references, value);
        return Default(schema, resolved);
    }
    function TThis(schema, references, value) {
        const target = (0, deref_1.Deref)(schema, references);
        const resolved = Visit(target, references, value);
        return Default(schema, resolved);
    }
    function TTuple(schema, references, value) {
        const value1 = (0, guard_1.IsArray)(schema.items) ? schema.items.map((schema, index) => Visit(schema, references, value[index])) : [];
        return Default(schema, value1);
    }
    function TUnion(schema, references, value) {
        const value1 = Default(schema, value);
        for (const subschema of schema.anyOf) {
            if (!checkFunction(subschema, references, value1))
                continue;
            return Visit(subschema, references, value1);
        }
        return value1;
    }
    function Visit(schema, references, value) {
        const references_ = typeof schema.$id === 'string' ? [...references, schema] : references;
        const schema_ = schema;
        switch (schema[Types.Kind]) {
            // ------------------------------------------------------
            // Structural
            // ------------------------------------------------------
            case 'Array':
                return TArray(schema_, references_, value);
            case 'Intersect':
                return TIntersect(schema_, references_, value);
            case 'Not':
                return TNot(schema_, references_, value);
            case 'Object':
                return TObject(schema_, references_, value);
            case 'Record':
                return TRecord(schema_, references_, value);
            case 'Ref':
                return TRef(schema_, references_, value);
            case 'Symbol':
                return Default(schema_, value);
            case 'This':
                return TThis(schema_, references_, value);
            case 'Tuple':
                return TTuple(schema_, references_, value);
            case 'Union':
                return TUnion(schema_, references_, value);
            // ------------------------------------------------------
            // Default
            // ------------------------------------------------------
            case 'Any':
            case 'AsyncIterator':
            case 'BigInt':
            case 'Boolean':
            case 'Constructor':
            case 'Date':
            case 'Function':
            case 'Integer':
            case 'Iterator':
            case 'Literal':
            case 'Never':
            case 'Null':
            case 'Number':
            case 'Promise':
            case 'String':
            case 'TemplateLiteral':
            case 'Undefined':
            case 'Uint8Array':
            case 'Unknown':
            case 'Void':
                return Default(schema_, value);
            default:
                if (!Types.TypeRegistry.Has(schema_[Types.Kind]))
                    throw new TransformUnknownTypeError(schema_);
                return Default(schema_, value);
        }
    }
    let checkFunction = () => false;
    function Decode(schema, references, value, check) {
        checkFunction = check;
        return Visit(schema, references, value);
    }
    DecodeTransform.Decode = Decode;
})(DecodeTransform || (exports.DecodeTransform = DecodeTransform = {}));
// -------------------------------------------------------------------------
// DecodeTransform
// -------------------------------------------------------------------------
/** Encodes a value using transform encoders if available. Does not ensure correct results. */
var EncodeTransform;
(function (EncodeTransform) {
    function Default(schema, value) {
        try {
            return Types.TypeGuard.TTransform(schema) ? schema[Types.Transform].Encode(value) : value;
        }
        catch (error) {
            throw new TransformEncodeError(schema, value, error);
        }
    }
    function TArray(schema, references, value) {
        const elements1 = Default(schema, value);
        return elements1.map((value) => Visit(schema.items, references, value));
    }
    function TIntersect(schema, references, value) {
        const properties1 = Default(schema, value);
        if (!(0, guard_1.IsPlainObject)(value) || (0, guard_1.IsValueType)(value))
            return properties1;
        const keys = Types.KeyResolver.ResolveKeys(schema, { includePatterns: false });
        const properties2 = Object.entries(properties1).reduce((acc, [key, value]) => {
            return !keys.includes(key) ? { ...acc, [key]: value } : { ...acc, [key]: Default(Types.IndexedAccessor.Resolve(schema, [key]), value) };
        }, {});
        if (!Types.TypeGuard.TTransform(schema.unevaluatedProperties))
            return Default(schema, properties2);
        return Object.entries(properties2).reduce((acc, [key, value]) => {
            return keys.includes(key) ? { ...acc, [key]: value } : { ...acc, [key]: Default(schema.unevaluatedProperties, value) };
        }, {});
    }
    function TNot(schema, references, value) {
        const value1 = Default(schema, value);
        return Default(schema.not, value1);
    }
    function TObject(schema, references, value) {
        const properties1 = Default(schema, value);
        if (!(0, guard_1.IsPlainObject)(value))
            return properties1;
        const properties2 = Object.entries(properties1).reduce((acc, [key, value]) => {
            return !(key in schema.properties) ? { ...acc, [key]: value } : { ...acc, [key]: Visit(schema.properties[key], references, value) };
        }, {});
        if (!Types.TypeGuard.TSchema(schema.additionalProperties))
            return properties2;
        const additionalProperties = schema.additionalProperties;
        return Object.entries(properties2).reduce((acc, [key, value]) => {
            return key in schema.properties ? { ...acc, [key]: value } : { ...acc, [key]: Visit(additionalProperties, references, value) };
        }, {});
    }
    function TRecord(schema, references, value) {
        const properties1 = Default(schema, value);
        if (!(0, guard_1.IsPlainObject)(value))
            return properties1;
        const pattern = Object.getOwnPropertyNames(schema.patternProperties)[0];
        const property = schema.patternProperties[pattern];
        const regex = new RegExp(pattern);
        const properties2 = Object.entries(properties1).reduce((acc, [key, value]) => {
            return !regex.test(key) ? { ...acc, [key]: value } : { ...acc, [key]: Visit(property, references, value) };
        }, {});
        if (!Types.TypeGuard.TSchema(schema.additionalProperties))
            return Default(schema, properties2);
        const additionalProperties = schema.additionalProperties;
        return Object.entries(properties2).reduce((acc, [key, value]) => {
            return regex.test(key) ? { ...acc, [key]: value } : { ...acc, [key]: Visit(additionalProperties, references, value) };
        }, {});
    }
    function TRef(schema, references, value) {
        const target = (0, deref_1.Deref)(schema, references);
        const resolved = Visit(target, references, value);
        return Default(schema, resolved);
    }
    function TThis(schema, references, value) {
        const target = (0, deref_1.Deref)(schema, references);
        const resolved = Visit(target, references, value);
        return Default(schema, resolved);
    }
    function TTuple(schema, references, value) {
        const value1 = Default(schema, value);
        return (0, guard_1.IsArray)(schema.items) ? schema.items.map((schema, index) => Visit(schema, references, value1[index])) : [];
    }
    function TUnion(schema, references, value) {
        for (const subschema of schema.anyOf) {
            if (!checkFunction(subschema, references, value))
                continue;
            const value1 = Visit(subschema, references, value);
            return Default(schema, value1);
        }
        return Default(schema, value);
    }
    function Visit(schema, references, value) {
        const references_ = typeof schema.$id === 'string' ? [...references, schema] : references;
        const schema_ = schema;
        switch (schema[Types.Kind]) {
            // ------------------------------------------------------
            // Structural
            // ------------------------------------------------------
            case 'Array':
                return TArray(schema_, references_, value);
            case 'Intersect':
                return TIntersect(schema_, references_, value);
            case 'Not':
                return TNot(schema_, references_, value);
            case 'Object':
                return TObject(schema_, references_, value);
            case 'Record':
                return TRecord(schema_, references_, value);
            case 'Ref':
                return TRef(schema_, references_, value);
            case 'This':
                return TThis(schema_, references_, value);
            case 'Tuple':
                return TTuple(schema_, references_, value);
            case 'Union':
                return TUnion(schema_, references_, value);
            // ------------------------------------------------------
            // Apply
            // ------------------------------------------------------
            case 'Any':
            case 'AsyncIterator':
            case 'BigInt':
            case 'Boolean':
            case 'Constructor':
            case 'Date':
            case 'Function':
            case 'Integer':
            case 'Iterator':
            case 'Literal':
            case 'Never':
            case 'Null':
            case 'Number':
            case 'Promise':
            case 'String':
            case 'Symbol':
            case 'TemplateLiteral':
            case 'Undefined':
            case 'Uint8Array':
            case 'Unknown':
            case 'Void':
                return Default(schema_, value);
            default:
                if (!Types.TypeRegistry.Has(schema_[Types.Kind]))
                    throw new TransformUnknownTypeError(schema_);
                return Default(schema_, value);
        }
    }
    let checkFunction = () => false;
    function Encode(schema, references, value, check) {
        checkFunction = check;
        return Visit(schema, references, value);
    }
    EncodeTransform.Encode = Encode;
})(EncodeTransform || (exports.EncodeTransform = EncodeTransform = {}));
