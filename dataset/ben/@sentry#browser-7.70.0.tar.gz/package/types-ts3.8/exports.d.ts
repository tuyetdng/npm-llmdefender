export { Breadcrumb, BreadcrumbHint, Request, SdkInfo, Event, EventHint, Exception, Severity, SeverityLevel, StackFrame, Stacktrace, Thread, Transaction, User, Session, } from '@sentry/types';
export { BrowserOptions } from './client';
export { ReportDialogOptions } from './helpers';
export { addGlobalEventProcessor, addBreadcrumb, captureException, captureEvent, captureMessage, close, configureScope, createTransport, flush, getHubFromCarrier, getCurrentHub, Hub, lastEventId, makeMain, Scope, startTransaction, getActiveSpan, startSpan, startInactiveSpan, startSpanManual, SDK_VERSION, setContext, setExtra, setExtras, setTag, setTags, setUser, withScope, FunctionToString, InboundFilters, } from '@sentry/core';
export { WINDOW } from './helpers';
export { BrowserClient } from './client';
export { makeFetchTransport, makeXHRTransport } from './transports';
export { defaultStackParser, defaultStackLineParsers, chromeStackLineParser, geckoStackLineParser, opera10StackLineParser, opera11StackLineParser, winjsStackLineParser, } from './stack-parsers';
export { eventFromException, eventFromMessage, exceptionFromError } from './eventbuilder';
export { createUserFeedbackEnvelope } from './userfeedback';
export { defaultIntegrations, forceLoad, init, onLoad, showReportDialog, captureUserFeedback, wrap, } from './sdk';
export { GlobalHandlers, TryCatch, Breadcrumbs, LinkedErrors, HttpContext, Dedupe } from './integrations';
//# sourceMappingURL=exports.d.ts.map
