import { DsnComponents, EventEnvelope, SdkMetadata, UserFeedback } from '@sentry/types';
/**
 * Creates an envelope from a user feedback.
 */
export declare function createUserFeedbackEnvelope(feedback: UserFeedback, { metadata, tunnel, dsn, }: {
    metadata: SdkMetadata | undefined;
    tunnel: string | undefined;
    dsn: DsnComponents | undefined;
}): EventEnvelope;
//# sourceMappingURL=userfeedback.d.ts.map
