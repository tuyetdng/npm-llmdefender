export const svgCaseSensitiveTagNames: string[];
