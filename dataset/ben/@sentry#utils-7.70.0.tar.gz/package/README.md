<p align="center">
  <a href="https://sentry.io/?utm_source=github&utm_medium=logo" target="_blank">
    <img src="https://sentry-brand.storage.googleapis.com/sentry-wordmark-dark-280x84.png" alt="Sentry" width="280" height="84">
  </a>
</p>

# Sentry JavaScript SDK Utilities

[![npm version](https://img.shields.io/npm/v/@sentry/utils.svg)](https://www.npmjs.com/package/@sentry/utils)
[![npm dm](https://img.shields.io/npm/dm/@sentry/utils.svg)](https://www.npmjs.com/package/@sentry/utils)
[![npm dt](https://img.shields.io/npm/dt/@sentry/utils.svg)](https://www.npmjs.com/package/@sentry/utils)

## Links

- [Official SDK Docs](https://docs.sentry.io/quickstart/)
- [TypeDoc](http://getsentry.github.io/sentry-javascript/)

## General

Common utilities used by the Sentry JavaScript SDKs.

Note: This package is only meant to be used internally, and as such is not part of our public API contract and does not follow semver.
